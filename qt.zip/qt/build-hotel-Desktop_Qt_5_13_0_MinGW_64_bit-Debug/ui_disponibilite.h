/********************************************************************************
** Form generated from reading UI file 'disponibilite.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISPONIBILITE_H
#define UI_DISPONIBILITE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_disponibilite
{
public:
    QTableView *tableView;
    QPushButton *affiche;

    void setupUi(QDialog *disponibilite)
    {
        if (disponibilite->objectName().isEmpty())
            disponibilite->setObjectName(QString::fromUtf8("disponibilite"));
        disponibilite->resize(600, 450);
        disponibilite->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 170, 0);"));
        tableView = new QTableView(disponibilite);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 70, 581, 371));
        tableView->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        affiche = new QPushButton(disponibilite);
        affiche->setObjectName(QString::fromUtf8("affiche"));
        affiche->setGeometry(QRect(10, 4, 581, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        affiche->setFont(font);
        affiche->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(disponibilite);

        QMetaObject::connectSlotsByName(disponibilite);
    } // setupUi

    void retranslateUi(QDialog *disponibilite)
    {
        disponibilite->setWindowTitle(QCoreApplication::translate("disponibilite", "SerenityScape", nullptr));
        affiche->setText(QCoreApplication::translate("disponibilite", "Afficher Les Chambres Libre", nullptr));
    } // retranslateUi

};

namespace Ui {
    class disponibilite: public Ui_disponibilite {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISPONIBILITE_H
