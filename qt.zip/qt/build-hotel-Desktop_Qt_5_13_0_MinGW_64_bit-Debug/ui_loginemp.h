/********************************************************************************
** Form generated from reading UI file 'loginemp.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINEMP_H
#define UI_LOGINEMP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_loginemp
{
public:
    QLabel *label_3;
    QPushButton *connect;
    QLabel *label_4;
    QLineEdit *code;

    void setupUi(QDialog *loginemp)
    {
        if (loginemp->objectName().isEmpty())
            loginemp->setObjectName(QString::fromUtf8("loginemp"));
        loginemp->resize(400, 300);
        loginemp->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        label_3 = new QLabel(loginemp);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(90, 20, 231, 51));
        QFont font;
        font.setPointSize(22);
        font.setBold(true);
        font.setWeight(75);
        label_3->setFont(font);
        connect = new QPushButton(loginemp);
        connect->setObjectName(QString::fromUtf8("connect"));
        connect->setGeometry(QRect(150, 210, 101, 41));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        connect->setFont(font1);
        connect->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        label_4 = new QLabel(loginemp);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(180, 110, 61, 22));
        QFont font2;
        font2.setPointSize(11);
        font2.setBold(true);
        font2.setWeight(75);
        label_4->setFont(font2);
        code = new QLineEdit(loginemp);
        code->setObjectName(QString::fromUtf8("code"));
        code->setGeometry(QRect(40, 140, 331, 22));

        retranslateUi(loginemp);

        QMetaObject::connectSlotsByName(loginemp);
    } // setupUi

    void retranslateUi(QDialog *loginemp)
    {
        loginemp->setWindowTitle(QCoreApplication::translate("loginemp", "SerenityScape", nullptr));
        label_3->setText(QCoreApplication::translate("loginemp", "WELCOME", nullptr));
        connect->setText(QCoreApplication::translate("loginemp", "Connect", nullptr));
        label_4->setText(QCoreApplication::translate("loginemp", "Code :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class loginemp: public Ui_loginemp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINEMP_H
