/********************************************************************************
** Form generated from reading UI file 'emphome.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPHOME_H
#define UI_EMPHOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_emphome
{
public:
    QPushButton *reservation;
    QPushButton *client;
    QPushButton *disponibilite;
    QPushButton *logout;

    void setupUi(QDialog *emphome)
    {
        if (emphome->objectName().isEmpty())
            emphome->setObjectName(QString::fromUtf8("emphome"));
        emphome->resize(400, 300);
        emphome->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        reservation = new QPushButton(emphome);
        reservation->setObjectName(QString::fromUtf8("reservation"));
        reservation->setGeometry(QRect(19, 110, 361, 71));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        reservation->setFont(font);
        reservation->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        client = new QPushButton(emphome);
        client->setObjectName(QString::fromUtf8("client"));
        client->setGeometry(QRect(20, 20, 361, 71));
        client->setFont(font);
        client->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        disponibilite = new QPushButton(emphome);
        disponibilite->setObjectName(QString::fromUtf8("disponibilite"));
        disponibilite->setGeometry(QRect(20, 200, 361, 71));
        disponibilite->setFont(font);
        disponibilite->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        logout = new QPushButton(emphome);
        logout->setObjectName(QString::fromUtf8("logout"));
        logout->setGeometry(QRect(170, 275, 80, 21));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        logout->setFont(font1);
        logout->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        client->raise();
        disponibilite->raise();
        logout->raise();
        reservation->raise();

        retranslateUi(emphome);

        QMetaObject::connectSlotsByName(emphome);
    } // setupUi

    void retranslateUi(QDialog *emphome)
    {
        emphome->setWindowTitle(QCoreApplication::translate("emphome", "SerenityScape", nullptr));
        reservation->setText(QCoreApplication::translate("emphome", "Reservation", nullptr));
        client->setText(QCoreApplication::translate("emphome", "Client", nullptr));
        disponibilite->setText(QCoreApplication::translate("emphome", "Disponibilite", nullptr));
        logout->setText(QCoreApplication::translate("emphome", "Logout", nullptr));
    } // retranslateUi

};

namespace Ui {
    class emphome: public Ui_emphome {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPHOME_H
