/********************************************************************************
** Form generated from reading UI file 'cludt.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLUDT_H
#define UI_CLUDT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_cludt
{
public:
    QTableView *tableView;
    QGroupBox *groupBox_2;
    QLabel *label;
    QLineEdit *nom;
    QLineEdit *prenom;
    QLabel *label_2;
    QLabel *label_4;
    QLineEdit *email;
    QDateEdit *datenaissance;
    QComboBox *sexe;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *tel;
    QLabel *label_7;
    QLineEdit *password;
    QLabel *label_8;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QPushButton *pushButton;

    void setupUi(QDialog *cludt)
    {
        if (cludt->objectName().isEmpty())
            cludt->setObjectName(QString::fromUtf8("cludt"));
        cludt->resize(1281, 478);
        cludt->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        tableView = new QTableView(cludt);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(710, 10, 571, 461));
        tableView->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        groupBox_2 = new QGroupBox(cludt);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(0, 10, 691, 461));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 120, 81, 21));
        nom = new QLineEdit(groupBox_2);
        nom->setObjectName(QString::fromUtf8("nom"));
        nom->setGeometry(QRect(170, 120, 471, 20));
        prenom = new QLineEdit(groupBox_2);
        prenom->setObjectName(QString::fromUtf8("prenom"));
        prenom->setGeometry(QRect(170, 160, 471, 20));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 160, 81, 21));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 200, 81, 21));
        email = new QLineEdit(groupBox_2);
        email->setObjectName(QString::fromUtf8("email"));
        email->setGeometry(QRect(170, 200, 471, 20));
        datenaissance = new QDateEdit(groupBox_2);
        datenaissance->setObjectName(QString::fromUtf8("datenaissance"));
        datenaissance->setGeometry(QRect(310, 320, 110, 22));
        datenaissance->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        sexe = new QComboBox(groupBox_2);
        sexe->addItem(QString());
        sexe->addItem(QString());
        sexe->setObjectName(QString::fromUtf8("sexe"));
        sexe->setGeometry(QRect(310, 360, 111, 22));
        sexe->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        label_5 = new QLabel(groupBox_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 320, 191, 21));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 360, 121, 21));
        tel = new QLineEdit(groupBox_2);
        tel->setObjectName(QString::fromUtf8("tel"));
        tel->setGeometry(QRect(170, 240, 471, 20));
        label_7 = new QLabel(groupBox_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 240, 141, 21));
        password = new QLineEdit(groupBox_2);
        password->setObjectName(QString::fromUtf8("password"));
        password->setGeometry(QRect(170, 280, 471, 20));
        label_8 = new QLabel(groupBox_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 280, 141, 21));
        pushButton_2 = new QPushButton(groupBox_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(570, 380, 111, 51));
        pushButton_2->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        lineEdit_3 = new QLineEdit(groupBox_2);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(170, 40, 331, 22));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 40, 141, 16));
        pushButton = new QPushButton(groupBox_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(570, 20, 111, 51));
        pushButton->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(cludt);

        QMetaObject::connectSlotsByName(cludt);
    } // setupUi

    void retranslateUi(QDialog *cludt)
    {
        cludt->setWindowTitle(QCoreApplication::translate("cludt", "SerenityScape", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("cludt", "Modifier un client", nullptr));
        label->setText(QCoreApplication::translate("cludt", "Nom :", nullptr));
        label_2->setText(QCoreApplication::translate("cludt", "Prenom :", nullptr));
        label_4->setText(QCoreApplication::translate("cludt", "E-mail :", nullptr));
        sexe->setItemText(0, QCoreApplication::translate("cludt", "Homme", nullptr));
        sexe->setItemText(1, QCoreApplication::translate("cludt", "Femme", nullptr));

        label_5->setText(QCoreApplication::translate("cludt", "Date de Naissance :", nullptr));
        label_6->setText(QCoreApplication::translate("cludt", "Sexe :", nullptr));
        label_7->setText(QCoreApplication::translate("cludt", "Telephone :", nullptr));
        label_8->setText(QCoreApplication::translate("cludt", "Password :", nullptr));
        pushButton_2->setText(QCoreApplication::translate("cludt", "Modifier", nullptr));
        label_3->setText(QCoreApplication::translate("cludt", " N\302\260 client:", nullptr));
        pushButton->setText(QCoreApplication::translate("cludt", "List of  \n"
"Clients", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cludt: public Ui_cludt {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLUDT_H
