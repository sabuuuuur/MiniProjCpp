/********************************************************************************
** Form generated from reading UI file 'claff.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLAFF_H
#define UI_CLAFF_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_claff
{
public:
    QTableView *tableView;
    QPushButton *affiche;

    void setupUi(QDialog *claff)
    {
        if (claff->objectName().isEmpty())
            claff->setObjectName(QString::fromUtf8("claff"));
        claff->resize(600, 448);
        claff->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        tableView = new QTableView(claff);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 70, 581, 371));
        tableView->setStyleSheet(QString::fromUtf8("background:rgb(255, 255, 255)"));
        affiche = new QPushButton(claff);
        affiche->setObjectName(QString::fromUtf8("affiche"));
        affiche->setGeometry(QRect(10, 4, 581, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        affiche->setFont(font);
        affiche->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(claff);

        QMetaObject::connectSlotsByName(claff);
    } // setupUi

    void retranslateUi(QDialog *claff)
    {
        claff->setWindowTitle(QCoreApplication::translate("claff", "SerenityScape", nullptr));
        affiche->setText(QCoreApplication::translate("claff", "Afficher Liste des Clients", nullptr));
    } // retranslateUi

};

namespace Ui {
    class claff: public Ui_claff {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLAFF_H
