/********************************************************************************
** Form generated from reading UI file 'empreservation.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPRESERVATION_H
#define UI_EMPRESERVATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_empreservation
{
public:
    QPushButton *ajouter;
    QPushButton *annuler;
    QPushButton *afficher;

    void setupUi(QDialog *empreservation)
    {
        if (empreservation->objectName().isEmpty())
            empreservation->setObjectName(QString::fromUtf8("empreservation"));
        empreservation->resize(500, 271);
        empreservation->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        ajouter = new QPushButton(empreservation);
        ajouter->setObjectName(QString::fromUtf8("ajouter"));
        ajouter->setGeometry(QRect(10, 10, 481, 71));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        ajouter->setFont(font);
        ajouter->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        annuler = new QPushButton(empreservation);
        annuler->setObjectName(QString::fromUtf8("annuler"));
        annuler->setGeometry(QRect(10, 190, 481, 71));
        annuler->setFont(font);
        annuler->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        afficher = new QPushButton(empreservation);
        afficher->setObjectName(QString::fromUtf8("afficher"));
        afficher->setGeometry(QRect(10, 100, 481, 71));
        afficher->setFont(font);
        afficher->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(empreservation);

        QMetaObject::connectSlotsByName(empreservation);
    } // setupUi

    void retranslateUi(QDialog *empreservation)
    {
        empreservation->setWindowTitle(QCoreApplication::translate("empreservation", "SerenityScape", nullptr));
        ajouter->setText(QCoreApplication::translate("empreservation", "Ajouter Reservation", nullptr));
        annuler->setText(QCoreApplication::translate("empreservation", "Annuler Reservation", nullptr));
        afficher->setText(QCoreApplication::translate("empreservation", "Afficher Reservation", nullptr));
    } // retranslateUi

};

namespace Ui {
    class empreservation: public Ui_empreservation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPRESERVATION_H
