/********************************************************************************
** Form generated from reading UI file 'empdisponibilite.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPDISPONIBILITE_H
#define UI_EMPDISPONIBILITE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_empdisponibilite
{
public:
    QTableView *tableView;
    QPushButton *affiche;

    void setupUi(QDialog *empdisponibilite)
    {
        if (empdisponibilite->objectName().isEmpty())
            empdisponibilite->setObjectName(QString::fromUtf8("empdisponibilite"));
        empdisponibilite->resize(600, 450);
        empdisponibilite->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        tableView = new QTableView(empdisponibilite);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 70, 581, 371));
        tableView->setStyleSheet(QString::fromUtf8("background:rgb(255, 255, 255)"));
        affiche = new QPushButton(empdisponibilite);
        affiche->setObjectName(QString::fromUtf8("affiche"));
        affiche->setGeometry(QRect(10, 4, 581, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        affiche->setFont(font);
        affiche->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(empdisponibilite);

        QMetaObject::connectSlotsByName(empdisponibilite);
    } // setupUi

    void retranslateUi(QDialog *empdisponibilite)
    {
        empdisponibilite->setWindowTitle(QCoreApplication::translate("empdisponibilite", "SerenityScape", nullptr));
        affiche->setText(QCoreApplication::translate("empdisponibilite", "Afficher Les Chambres Libre", nullptr));
    } // retranslateUi

};

namespace Ui {
    class empdisponibilite: public Ui_empdisponibilite {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPDISPONIBILITE_H
