/********************************************************************************
** Form generated from reading UI file 'ajoutclient.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTCLIENT_H
#define UI_AJOUTCLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ajoutclient
{
public:
    QGroupBox *groupBox;
    QLabel *label;
    QLineEdit *nom;
    QLineEdit *prenom;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *email;
    QDateEdit *datenaissance;
    QComboBox *sexe;
    QLabel *label_4;
    QPushButton *registre;
    QLabel *label_5;
    QLineEdit *tel;
    QLabel *label_6;
    QLineEdit *password;
    QLabel *label_7;

    void setupUi(QDialog *ajoutclient)
    {
        if (ajoutclient->objectName().isEmpty())
            ajoutclient->setObjectName(QString::fromUtf8("ajoutclient"));
        ajoutclient->resize(800, 500);
        ajoutclient->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        groupBox = new QGroupBox(ajoutclient);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(40, 40, 721, 391));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 50, 81, 21));
        nom = new QLineEdit(groupBox);
        nom->setObjectName(QString::fromUtf8("nom"));
        nom->setGeometry(QRect(170, 50, 471, 20));
        prenom = new QLineEdit(groupBox);
        prenom->setObjectName(QString::fromUtf8("prenom"));
        prenom->setGeometry(QRect(170, 90, 471, 20));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 90, 81, 21));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 130, 81, 21));
        email = new QLineEdit(groupBox);
        email->setObjectName(QString::fromUtf8("email"));
        email->setGeometry(QRect(170, 130, 471, 20));
        datenaissance = new QDateEdit(groupBox);
        datenaissance->setObjectName(QString::fromUtf8("datenaissance"));
        datenaissance->setGeometry(QRect(310, 250, 110, 22));
        datenaissance->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        sexe = new QComboBox(groupBox);
        sexe->addItem(QString());
        sexe->addItem(QString());
        sexe->setObjectName(QString::fromUtf8("sexe"));
        sexe->setGeometry(QRect(310, 290, 111, 22));
        sexe->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 250, 191, 21));
        registre = new QPushButton(groupBox);
        registre->setObjectName(QString::fromUtf8("registre"));
        registre->setGeometry(QRect(300, 340, 121, 41));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        registre->setFont(font);
        registre->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 290, 121, 21));
        tel = new QLineEdit(groupBox);
        tel->setObjectName(QString::fromUtf8("tel"));
        tel->setGeometry(QRect(170, 170, 471, 20));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 170, 141, 21));
        password = new QLineEdit(groupBox);
        password->setObjectName(QString::fromUtf8("password"));
        password->setGeometry(QRect(170, 210, 471, 20));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 210, 141, 21));

        retranslateUi(ajoutclient);

        QMetaObject::connectSlotsByName(ajoutclient);
    } // setupUi

    void retranslateUi(QDialog *ajoutclient)
    {
        ajoutclient->setWindowTitle(QCoreApplication::translate("ajoutclient", "SerenityScape", nullptr));
        groupBox->setTitle(QCoreApplication::translate("ajoutclient", "Inscription :", nullptr));
        label->setText(QCoreApplication::translate("ajoutclient", "Nom :", nullptr));
        label_2->setText(QCoreApplication::translate("ajoutclient", "Prenom :", nullptr));
        label_3->setText(QCoreApplication::translate("ajoutclient", "E-mail :", nullptr));
        sexe->setItemText(0, QCoreApplication::translate("ajoutclient", "Homme", nullptr));
        sexe->setItemText(1, QCoreApplication::translate("ajoutclient", "Femme", nullptr));

        label_4->setText(QCoreApplication::translate("ajoutclient", "Date de Naissance :", nullptr));
        registre->setText(QCoreApplication::translate("ajoutclient", "REGISTRE", nullptr));
        label_5->setText(QCoreApplication::translate("ajoutclient", "Sexe :", nullptr));
        label_6->setText(QCoreApplication::translate("ajoutclient", "Telephone :", nullptr));
        label_7->setText(QCoreApplication::translate("ajoutclient", "Password :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ajoutclient: public Ui_ajoutclient {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTCLIENT_H
