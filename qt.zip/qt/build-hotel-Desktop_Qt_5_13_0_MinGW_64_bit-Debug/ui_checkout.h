/********************************************************************************
** Form generated from reading UI file 'checkout.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHECKOUT_H
#define UI_CHECKOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_checkout
{
public:
    QTableView *tableView;
    QGroupBox *groupBox;
    QLabel *label_3;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *checkout)
    {
        if (checkout->objectName().isEmpty())
            checkout->setObjectName(QString::fromUtf8("checkout"));
        checkout->resize(1300, 257);
        checkout->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 170, 0);"));
        tableView = new QTableView(checkout);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(540, 20, 751, 221));
        tableView->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        groupBox = new QGroupBox(checkout);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(20, 10, 491, 231));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 60, 141, 16));
        lineEdit_3 = new QLineEdit(groupBox);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(140, 60, 331, 22));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(100, 150, 111, 51));
        pushButton->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(290, 150, 111, 51));
        pushButton_2->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(checkout);

        QMetaObject::connectSlotsByName(checkout);
    } // setupUi

    void retranslateUi(QDialog *checkout)
    {
        checkout->setWindowTitle(QCoreApplication::translate("checkout", "SerenityScape", nullptr));
        groupBox->setTitle(QCoreApplication::translate("checkout", "Checkout:", nullptr));
        label_3->setText(QCoreApplication::translate("checkout", "Resevation N\302\260:", nullptr));
        pushButton->setText(QCoreApplication::translate("checkout", "List of  \n"
"Reservations", nullptr));
        pushButton_2->setText(QCoreApplication::translate("checkout", "Checkout", nullptr));
    } // retranslateUi

};

namespace Ui {
    class checkout: public Ui_checkout {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHECKOUT_H
