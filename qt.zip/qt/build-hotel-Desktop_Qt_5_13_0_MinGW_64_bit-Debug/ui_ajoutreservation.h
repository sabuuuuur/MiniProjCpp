/********************************************************************************
** Form generated from reading UI file 'ajoutreservation.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUTRESERVATION_H
#define UI_AJOUTRESERVATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ajoutreservation
{
public:
    QPushButton *load;
    QTableView *tableView;
    QPushButton *confirme;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QDateEdit *date_arrivee;
    QLabel *label_2;
    QDateEdit *date_depart;
    QLabel *label_3;
    QComboBox *chambre;

    void setupUi(QDialog *ajoutreservation)
    {
        if (ajoutreservation->objectName().isEmpty())
            ajoutreservation->setObjectName(QString::fromUtf8("ajoutreservation"));
        ajoutreservation->resize(550, 600);
        ajoutreservation->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        load = new QPushButton(ajoutreservation);
        load->setObjectName(QString::fromUtf8("load"));
        load->setGeometry(QRect(290, 540, 121, 51));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        font.setWeight(75);
        load->setFont(font);
        load->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        tableView = new QTableView(ajoutreservation);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 230, 531, 301));
        tableView->setStyleSheet(QString::fromUtf8("background:rgb(255, 255, 255)"));
        confirme = new QPushButton(ajoutreservation);
        confirme->setObjectName(QString::fromUtf8("confirme"));
        confirme->setGeometry(QRect(140, 540, 121, 51));
        confirme->setFont(font);
        confirme->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        formLayoutWidget = new QWidget(ajoutreservation);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 531, 201));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);

        formLayout->setWidget(0, QFormLayout::SpanningRole, label);

        date_arrivee = new QDateEdit(formLayoutWidget);
        date_arrivee->setObjectName(QString::fromUtf8("date_arrivee"));
        QFont font2;
        font2.setPointSize(12);
        date_arrivee->setFont(font2);
        date_arrivee->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        formLayout->setWidget(1, QFormLayout::SpanningRole, date_arrivee);

        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font1);

        formLayout->setWidget(2, QFormLayout::SpanningRole, label_2);

        date_depart = new QDateEdit(formLayoutWidget);
        date_depart->setObjectName(QString::fromUtf8("date_depart"));
        date_depart->setFont(font2);
        date_depart->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        formLayout->setWidget(3, QFormLayout::SpanningRole, date_depart);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font1);

        formLayout->setWidget(4, QFormLayout::SpanningRole, label_3);

        chambre = new QComboBox(formLayoutWidget);
        chambre->setObjectName(QString::fromUtf8("chambre"));
        chambre->setFont(font2);
        chambre->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        formLayout->setWidget(5, QFormLayout::SpanningRole, chambre);


        retranslateUi(ajoutreservation);

        QMetaObject::connectSlotsByName(ajoutreservation);
    } // setupUi

    void retranslateUi(QDialog *ajoutreservation)
    {
        ajoutreservation->setWindowTitle(QCoreApplication::translate("ajoutreservation", "SerenityScape", nullptr));
        load->setText(QCoreApplication::translate("ajoutreservation", "Load Data", nullptr));
        confirme->setText(QCoreApplication::translate("ajoutreservation", "Confirme", nullptr));
        label->setText(QCoreApplication::translate("ajoutreservation", "Date d'Arrivee :", nullptr));
        label_2->setText(QCoreApplication::translate("ajoutreservation", "Date de Depart :", nullptr));
        label_3->setText(QCoreApplication::translate("ajoutreservation", "chambres Disponible :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ajoutreservation: public Ui_ajoutreservation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUTRESERVATION_H
