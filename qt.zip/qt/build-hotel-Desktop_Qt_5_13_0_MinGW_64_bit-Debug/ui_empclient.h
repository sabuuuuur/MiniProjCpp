/********************************************************************************
** Form generated from reading UI file 'empclient.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPCLIENT_H
#define UI_EMPCLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_empclient
{
public:
    QPushButton *ajouter;
    QPushButton *modifier;
    QPushButton *afficher;
    QPushButton *Supprimer;

    void setupUi(QDialog *empclient)
    {
        if (empclient->objectName().isEmpty())
            empclient->setObjectName(QString::fromUtf8("empclient"));
        empclient->resize(500, 358);
        empclient->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        ajouter = new QPushButton(empclient);
        ajouter->setObjectName(QString::fromUtf8("ajouter"));
        ajouter->setGeometry(QRect(10, 10, 481, 71));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        ajouter->setFont(font);
        ajouter->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        modifier = new QPushButton(empclient);
        modifier->setObjectName(QString::fromUtf8("modifier"));
        modifier->setGeometry(QRect(10, 190, 481, 71));
        modifier->setFont(font);
        modifier->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        afficher = new QPushButton(empclient);
        afficher->setObjectName(QString::fromUtf8("afficher"));
        afficher->setGeometry(QRect(10, 100, 481, 71));
        afficher->setFont(font);
        afficher->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        Supprimer = new QPushButton(empclient);
        Supprimer->setObjectName(QString::fromUtf8("Supprimer"));
        Supprimer->setGeometry(QRect(10, 280, 481, 71));
        Supprimer->setFont(font);
        Supprimer->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(empclient);

        QMetaObject::connectSlotsByName(empclient);
    } // setupUi

    void retranslateUi(QDialog *empclient)
    {
        empclient->setWindowTitle(QCoreApplication::translate("empclient", "SerenityScape", nullptr));
        ajouter->setText(QCoreApplication::translate("empclient", "Ajouter Client", nullptr));
        modifier->setText(QCoreApplication::translate("empclient", "Modifier Client", nullptr));
        afficher->setText(QCoreApplication::translate("empclient", "Afficher Clients", nullptr));
        Supprimer->setText(QCoreApplication::translate("empclient", "Supprimer Client", nullptr));
    } // retranslateUi

};

namespace Ui {
    class empclient: public Ui_empclient {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPCLIENT_H
