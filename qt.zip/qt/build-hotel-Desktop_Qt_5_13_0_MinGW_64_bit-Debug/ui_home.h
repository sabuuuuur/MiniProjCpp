/********************************************************************************
** Form generated from reading UI file 'home.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOME_H
#define UI_HOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_home
{
public:
    QPushButton *annulation;
    QPushButton *reservation;
    QPushButton *logout;
    QPushButton *CheckOut;
    QPushButton *Disponibilite;
    QLabel *label;

    void setupUi(QDialog *home)
    {
        if (home->objectName().isEmpty())
            home->setObjectName(QString::fromUtf8("home"));
        home->resize(650, 450);
        home->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 170, 0);"));
        annulation = new QPushButton(home);
        annulation->setObjectName(QString::fromUtf8("annulation"));
        annulation->setGeometry(QRect(29, 350, 591, 51));
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        annulation->setFont(font);
        annulation->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        reservation = new QPushButton(home);
        reservation->setObjectName(QString::fromUtf8("reservation"));
        reservation->setGeometry(QRect(460, 60, 161, 71));
        QFont font1;
        font1.setPointSize(11);
        font1.setBold(true);
        font1.setWeight(75);
        reservation->setFont(font1);
        reservation->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        logout = new QPushButton(home);
        logout->setObjectName(QString::fromUtf8("logout"));
        logout->setGeometry(QRect(500, 15, 80, 31));
        QFont font2;
        font2.setPointSize(9);
        font2.setBold(true);
        font2.setWeight(75);
        logout->setFont(font2);
        logout->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        CheckOut = new QPushButton(home);
        CheckOut->setObjectName(QString::fromUtf8("CheckOut"));
        CheckOut->setGeometry(QRect(460, 240, 161, 71));
        CheckOut->setFont(font1);
        CheckOut->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        Disponibilite = new QPushButton(home);
        Disponibilite->setObjectName(QString::fromUtf8("Disponibilite"));
        Disponibilite->setGeometry(QRect(460, 150, 161, 71));
        Disponibilite->setFont(font1);
        Disponibilite->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        label = new QLabel(home);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 30, 421, 281));
        label->setStyleSheet(QString::fromUtf8("image: url(:/pic1.jpg);"));

        retranslateUi(home);

        QMetaObject::connectSlotsByName(home);
    } // setupUi

    void retranslateUi(QDialog *home)
    {
        home->setWindowTitle(QCoreApplication::translate("home", "SerenityScape", nullptr));
        annulation->setText(QCoreApplication::translate("home", "Annulation", nullptr));
        reservation->setText(QCoreApplication::translate("home", "Reservation", nullptr));
        logout->setText(QCoreApplication::translate("home", "Logout", nullptr));
        CheckOut->setText(QCoreApplication::translate("home", "CheckOut", nullptr));
        Disponibilite->setText(QCoreApplication::translate("home", "Disponibilite", nullptr));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class home: public Ui_home {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOME_H
