/********************************************************************************
** Form generated from reading UI file 'resaff.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESAFF_H
#define UI_RESAFF_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_resaff
{
public:
    QTableView *tableView;
    QPushButton *affiche;

    void setupUi(QDialog *resaff)
    {
        if (resaff->objectName().isEmpty())
            resaff->setObjectName(QString::fromUtf8("resaff"));
        resaff->resize(592, 445);
        resaff->setStyleSheet(QString::fromUtf8("background:rgb(255, 147, 133)"));
        tableView = new QTableView(resaff);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 70, 581, 371));
        tableView->setStyleSheet(QString::fromUtf8("background:rgb(255, 255, 255)"));
        affiche = new QPushButton(resaff);
        affiche->setObjectName(QString::fromUtf8("affiche"));
        affiche->setGeometry(QRect(10, 4, 581, 51));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        affiche->setFont(font);
        affiche->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(resaff);

        QMetaObject::connectSlotsByName(resaff);
    } // setupUi

    void retranslateUi(QDialog *resaff)
    {
        resaff->setWindowTitle(QCoreApplication::translate("resaff", "SerenityScape", nullptr));
        affiche->setText(QCoreApplication::translate("resaff", "Afficher Liste des Reservations", nullptr));
    } // retranslateUi

};

namespace Ui {
    class resaff: public Ui_resaff {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESAFF_H
