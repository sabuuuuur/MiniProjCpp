/********************************************************************************
** Form generated from reading UI file 'reservation.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RESERVATION_H
#define UI_RESERVATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_reservation
{
public:
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QDateEdit *date_arrivee;
    QLabel *label_2;
    QDateEdit *date_depart;
    QLabel *label_3;
    QComboBox *chambre;
    QTableView *tableView;
    QPushButton *confirme;
    QPushButton *load;

    void setupUi(QDialog *reservation)
    {
        if (reservation->objectName().isEmpty())
            reservation->setObjectName(QString::fromUtf8("reservation"));
        reservation->resize(550, 600);
        reservation->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 170, 0);"));
        formLayoutWidget = new QWidget(reservation);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(10, 10, 531, 201));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);

        formLayout->setWidget(0, QFormLayout::SpanningRole, label);

        date_arrivee = new QDateEdit(formLayoutWidget);
        date_arrivee->setObjectName(QString::fromUtf8("date_arrivee"));
        QFont font1;
        font1.setPointSize(12);
        date_arrivee->setFont(font1);
        date_arrivee->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        formLayout->setWidget(1, QFormLayout::SpanningRole, date_arrivee);

        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);

        formLayout->setWidget(2, QFormLayout::SpanningRole, label_2);

        date_depart = new QDateEdit(formLayoutWidget);
        date_depart->setObjectName(QString::fromUtf8("date_depart"));
        date_depart->setFont(font1);
        date_depart->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        formLayout->setWidget(3, QFormLayout::SpanningRole, date_depart);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);

        formLayout->setWidget(4, QFormLayout::SpanningRole, label_3);

        chambre = new QComboBox(formLayoutWidget);
        chambre->setObjectName(QString::fromUtf8("chambre"));
        chambre->setFont(font1);
        chambre->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        formLayout->setWidget(5, QFormLayout::SpanningRole, chambre);

        tableView = new QTableView(reservation);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 230, 531, 301));
        tableView->setStyleSheet(QString::fromUtf8("background:rgb(255, 255, 255)"));
        confirme = new QPushButton(reservation);
        confirme->setObjectName(QString::fromUtf8("confirme"));
        confirme->setGeometry(QRect(140, 540, 121, 51));
        QFont font2;
        font2.setPointSize(11);
        font2.setBold(true);
        font2.setWeight(75);
        confirme->setFont(font2);
        confirme->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));
        load = new QPushButton(reservation);
        load->setObjectName(QString::fromUtf8("load"));
        load->setGeometry(QRect(290, 540, 121, 51));
        load->setFont(font2);
        load->setStyleSheet(QString::fromUtf8("background:rgb(214, 214, 214)"));

        retranslateUi(reservation);

        QMetaObject::connectSlotsByName(reservation);
    } // setupUi

    void retranslateUi(QDialog *reservation)
    {
        reservation->setWindowTitle(QCoreApplication::translate("reservation", "SerenityScape", nullptr));
        label->setText(QCoreApplication::translate("reservation", "Date d'Arrivee :", nullptr));
        label_2->setText(QCoreApplication::translate("reservation", "Date de Depart :", nullptr));
        label_3->setText(QCoreApplication::translate("reservation", "chambres Disponible :", nullptr));
        confirme->setText(QCoreApplication::translate("reservation", "Confirme", nullptr));
        load->setText(QCoreApplication::translate("reservation", "Load Data", nullptr));
    } // retranslateUi

};

namespace Ui {
    class reservation: public Ui_reservation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RESERVATION_H
