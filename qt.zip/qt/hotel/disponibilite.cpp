#include "disponibilite.h"
#include "ui_disponibilite.h"

disponibilite::disponibilite(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::disponibilite)
{
    ui->setupUi(this);
}

disponibilite::~disponibilite()
{
    delete ui;

    delete mod;
}

void disponibilite::on_affiche_clicked()
{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
    {
        qDebug()<<"Database file exists";
    }
    else
    {
        qDebug()<<"erreur Database";
        return;
    }

    if(!database.open())
    {
        qDebug()<< "Erreur : impossible d'ouvrire Database";
    }
    else
    {
        qDebug()<<"Database est ouvert!";
    }

//    QSqlQuery query;
//    query = QSqlQuery(database);

//    query.prepare("SELECT id_type, nomchambre FROM chambre where dispo=0");
    QSqlQuery query, queryType;

    query = QSqlQuery(database);
    queryType = QSqlQuery(database);

    query.prepare("select nomchambre, id_type from chambre where dispo=0");
    query.exec();

    QSqlQueryModel *modelChambre = new QSqlQueryModel;
    modelChambre->setQuery(query);


    int ligne = 0;
    query.exec("select count(*) from chambre where dispo=0");
    while (query.next()) {
        ligne = query.value(0).toInt();
    }

    mod = new QStandardItemModel(ligne, 2);
    int row = 0;
    query.exec("select nomchambre, id_type from chambre where dispo=0 ");
    while (query.next()) {
        for (int j = 0; j < 2; j++) {
            QStandardItem *item = new QStandardItem(query.value(j).toString());
            mod->setItem(row, j, item);

            if (j == 1) {
                // Si la colonne est celle des types de chambre, récupérer le nom du type
                int typeId = query.value(1).toInt();
                queryType.prepare("select nomtype from typechambre where id_type=:id");
                queryType.bindValue(":id", typeId);
                queryType.exec();

                if (queryType.next()) {
                    QStandardItem *typeItem = new QStandardItem(queryType.value(0).toString());
                    mod->setItem(row, 1, typeItem);
                }
            }
        }
        row++;
    }

    mod->setHeaderData(0, Qt::Horizontal, "Nom Chambre");
    mod->setHeaderData(1, Qt::Horizontal, "Type Chambre");
    ui->tableView->setModel(mod);

    qDebug()<<"last error :"<<query.lastError().text();
    database.close();

}

