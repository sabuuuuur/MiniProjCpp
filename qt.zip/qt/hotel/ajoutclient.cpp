#include "ajoutclient.h"
#include "ui_ajoutclient.h"

ajoutclient::ajoutclient(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajoutclient)
{
    ui->setupUi(this);
}

ajoutclient::~ajoutclient()
{
    delete ui;
}

void ajoutclient::on_registre_clicked()
{
    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString email = ui->email->text();
    QString datenaissance = ui->datenaissance->text();
    QString tel = ui->tel->text();
    QString sexe = ui->sexe->currentText();
    QString password = ui->password->text();


    if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || datenaissance.isEmpty() || tel.isEmpty() || password.isEmpty()) {
        QMessageBox::information(this,"Attention","Vous devez remplir tous les champs !!");
    } else {
        qDebug()<<"Nom : "<<nom<<" Prenom : "<<prenom<<" email : "<<email<<"date de naissance : "<<datenaissance<<" sexe :"<<sexe<<" password :"<<password;

        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

        if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
        {
            qDebug()<<"Database file exists";
        }
        else
        {
            qDebug()<<"erreur Database";
            return;
        }

        if(!database.open())
        {
            qDebug()<< "Erreur : impossible d'ouvrire Database";
        }
        else
        {
            qDebug()<<"Database est ouvert!";
        }

        QSqlQuery query;
        query = QSqlQuery(database);

        query.prepare("insert into client (nom,prenom,email,date_naissance,tel,sexe,password) values('"+nom+"','"+prenom+"','"+email+"','"+datenaissance+"','"+tel+"','"+sexe+"','"+password+"')");
        query.exec();
        qDebug()<<"last error :"<<query.lastError().text();
        database.close();

        this->hide();
    }
}
