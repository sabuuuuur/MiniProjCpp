#ifndef CLUDT_H
#define CLUDT_H

#include <QDialog>
#include "database.h"
#include<QStandardItemModel>


namespace Ui {
class cludt;
}

class cludt : public QDialog
{
    Q_OBJECT

public:
    explicit cludt(QWidget *parent = nullptr);
    ~cludt();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::cludt *ui;
    QStandardItemModel *mod2;

};

#endif // CLUDT_H
