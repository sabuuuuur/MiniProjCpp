#ifndef LOGINEMP_H
#define LOGINEMP_H

#include <QDialog>

#include "emphome.h"
#include "database.h"

namespace Ui {
class loginemp;
}

class loginemp : public QDialog
{
    Q_OBJECT

public:
    explicit loginemp(QWidget *parent = nullptr);
    ~loginemp();

private slots:
    void on_connect_clicked();

private:
    Ui::loginemp *ui;

    emphome *ptremphome;
};

#endif // LOGINEMP_H
