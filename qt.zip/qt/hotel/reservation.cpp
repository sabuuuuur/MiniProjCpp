//#include "reservation.h"
//#include "ui_reservation.h"

//reservation::reservation(QWidget *parent) :
//    QDialog(parent),
//    ui(new Ui::reservation)
//{
//    ui->setupUi(this);

////    affichagetableview();
//}

//reservation::~reservation()
//{
//    delete ui;

//    delete mod;
//}

//void reservation::on_load_clicked(){
//        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
//        database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

//        if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
//        {
//            qDebug()<<"Database file exists";
//        }
//        else
//        {
//            qDebug()<<"erreur Database";
//            return;
//        }

//        if(!database.open())
//        {
//            qDebug()<< "Erreur : impossible d'ouvrire Database";
//        }
//        else
//        {
//            qDebug()<<"Database est ouvert!";
//        }

//        QSqlQuery query, queryType;

//        query = QSqlQuery(database);
//        queryType = QSqlQuery(database);

//        query.prepare("select nomchambre, id_type from chambre where dispo=0");
//        query.exec();

//        QSqlQueryModel *modelChambre = new QSqlQueryModel;
//        modelChambre->setQuery(query);


//        int ligne = 0;
//        query.exec("select count(*) from chambre");
//        while (query.next()) {
//            ligne = query.value(0).toInt();
//        }

//        mod = new QStandardItemModel(ligne, 2);
//        int row = 0;
//        query.exec("select nomchambre, id_type from chambre");
//        while (query.next()) {
//            for (int j = 0; j < 2; j++) {
//                QStandardItem *item = new QStandardItem(query.value(j).toString());
//                mod->setItem(row, j, item);

//                if (j == 1) {
//                    // Si la colonne est celle des types de chambre, récupérer le nom du type
//                    int typeId = query.value(1).toInt();
//                    queryType.prepare("select nomtype from typechambre where id_type=:id");
//                    queryType.bindValue(":id", typeId);
//                    queryType.exec();

//                    if (queryType.next()) {
//                        QStandardItem *typeItem = new QStandardItem(queryType.value(0).toString());
//                        mod->setItem(row, 1, typeItem);
//                    }
//                }
//            }
//            row++;
//        }

//        mod->setHeaderData(0, Qt::Horizontal, "Nom Chambre");
//        mod->setHeaderData(1, Qt::Horizontal, "Type Chambre");
//        ui->tableView->setModel(mod);

//        ui->chambre->setModel(modelChambre);

//        qDebug()<<"last error :"<<query.lastError().text();
//        database.close();
//}

////void reservation::on_load_clicked(){
////        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
////        database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

////        if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db"))
////        {
////            qDebug()<<"Database file exists";
////        }
////        else
////        {
////            qDebug()<<"erreur Database";
////            return;
////        }

////        if(!database.open())
////        {
////            qDebug()<< "Erreur : impossible d'ouvrire Database";
////        }
////        else
////        {
////            qDebug()<<"Database est ouvert!";
////        }

////        QSqlQuery query;

////        query = QSqlQuery(database);

////        query.prepare("select nomchambre from chambre where dispo=0");
////        query.exec();
////        QSqlQueryModel *modelChambre = new QSqlQueryModel;
////        modelChambre->setQuery(query);
////        ui->chambre->setModel(modelChambre);

////        qDebug()<<"last error :"<<query.lastError().text();
////        database.close();
////}

////void reservation::affichagetableview()
////{
////    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
////    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

////    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db"))
////    {
////        qDebug()<<"Database file exists";
////    }
////    else
////    {
////        qDebug()<<"erreur Database";
////        return;
////    }

////    if(!database.open())
////    {
////        qDebug()<< "Erreur : impossible d'ouvrire Database";
////    }
////    else
////    {
////        qDebug()<<"Database est ouvert!";
////    }

////    QSqlQuery query/*,query1*/;

////    query = QSqlQuery(database);
//////    query1 = QSqlQuery(database);

////    query.prepare("select nomchambre from chambre where dispo=0");
////    query.exec();

//////    query1.prepare("select nomchambre,id_type from chambre where dispo=0");
//////    query1.exec();

////    QSqlQueryModel *modelChambre = new QSqlQueryModel;
//////    QSqlQueryModel *modele = new QSqlQueryModel;

////    modelChambre->setQuery(query);
//////    modele->setQuery(query1);


////    QSqlQuery req,req2;
////        int ligne (0);
////        req.exec("select count(*) from chambre");
////        while (req.next()) {
////            ligne=req.value(0).toInt();
////        }


////        mod = new QStandardItemModel (ligne, 2);
////        int row(0),i;
////        req.exec("select nomchambre,id_type from chambre");
////        //req.next();

////        /*i=req.value(1).toInt();

////        req2.exec("select nomtype from typechambre where id_type=:i  ");
////        req2.bindValue(":i",i);
////        req2.next();*/

////        while (req.next()) {

////            for (int j=0 ;j<2;j++) {



////                 QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
////                 mod->setItem(row,j,item);
////                 if(j==1){

////                     i=req.value(1).toInt();
////                     req2.bindValue(":i",i);
////                     req2.exec("select nomtype from typechambre where id_type=:i  ");


////                     req2.next();




////                 QStandardItem *item = new QStandardItem(req2.value (0).toString()) ;


////                 mod->setItem(row,1,item);
////                 }
////                if(j==0){



////                QStandardItem *item = new QStandardItem(req.value (j).toString()) ;

////                mod->setItem(row,j,item);


////                }
////            }
////            row++;

////        }

////              //QTableView *Ui_checkout::;

////            mod->setHeaderData (0, Qt::Horizontal, "Nom Chmabre");
////            mod->setHeaderData (1, Qt::Horizontal, "Type Chambre");
////            ui->tableView->setModel(mod);


////    ui->chambre->setModel(modelChambre);

////    qDebug()<<"last error :"<<query.lastError().text();
////    database.close();

////}

////void reservation::affichagetableview()
////{
////    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
////    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

////    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db"))
////    {
////        qDebug()<<"Database file exists";
////    }
////    else
////    {
////        qDebug()<<"erreur Database";
////        return;
////    }

////    if(!database.open())
////    {
////        qDebug()<< "Erreur : impossible d'ouvrire Database";
////    }
////    else
////    {
////        qDebug()<<"Database est ouvert!";
////    }

////    QSqlQuery query, queryType;

////    query = QSqlQuery(database);
////    queryType = QSqlQuery(database);

////    query.prepare("select nomchambre, id_type from chambre where dispo=0");
////    query.exec();

////    QSqlQueryModel *modelChambre = new QSqlQueryModel;
////    modelChambre->setQuery(query);


////    int ligne = 0;
////    query.exec("select count(*) from chambre");
////    while (query.next()) {
////        ligne = query.value(0).toInt();
////    }

////    mod = new QStandardItemModel(ligne, 2);
////    int row = 0;
////    query.exec("select nomchambre, id_type from chambre");
////    while (query.next()) {
////        for (int j = 0; j < 2; j++) {
////            QStandardItem *item = new QStandardItem(query.value(j).toString());
////            mod->setItem(row, j, item);

////            if (j == 1) {
////                // Si la colonne est celle des types de chambre, récupérer le nom du type
////                int typeId = query.value(1).toInt();
////                queryType.prepare("select nomtype from typechambre where id_type=:id");
////                queryType.bindValue(":id", typeId);
////                queryType.exec();

////                if (queryType.next()) {
////                    QStandardItem *typeItem = new QStandardItem(queryType.value(0).toString());
////                    mod->setItem(row, 1, typeItem);
////                }
////            }
////        }
////        row++;
////    }

////    mod->setHeaderData(0, Qt::Horizontal, "Nom Chambre");
////    mod->setHeaderData(1, Qt::Horizontal, "Type Chambre");
////    ui->tableView->setModel(mod);

////    ui->chambre->setModel(modelChambre);

////    qDebug()<<"last error :"<<query.lastError().text();
////    database.close();
////}


//void reservation::on_confirme_clicked()
//{
//    QString date_depart1 = ui->date_depart->text();
//    QString date_arrivee1 = ui->date_arrivee->text();
//    QString nomchambre = ui->chambre->currentText();
//    QDate date_depart=ui->date_depart->date();
//    QDate date_arrivee = ui->date_arrivee->date();

//    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
//    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

//    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
//    {
//        qDebug()<<"Database file exists";
//    }
//    else
//    {
//        qDebug()<<"erreur Database";
//        return;
//    }

//    if(!database.open())
//    {
//        qDebug()<< "Erreur : impossible d'ouvrire Database";
//    }
//    else
//    {
//        qDebug()<<"Database est ouvert!";
//    }

//    QSqlQuery query;
//    query = QSqlQuery(database);
//    query.prepare("update chambre set dispo=1 where nomchambre=:nomchambre");
//    query.bindValue(":nomchambre",nomchambre);
//    query.exec();

//    QSqlQuery query1,query2,query3,query4,query5,query6;
//    query1 = QSqlQuery(database);
//    query2 = QSqlQuery(database);
//    query3 = QSqlQuery(database);
//    query4 = QSqlQuery(database);
//    query5 = QSqlQuery(database);
//    query6 = QSqlQuery(database);

//    QString val1,que,que1,que2,val2,val3,que3,val4,val5,que4;
//    int prix;

//    que="select emaili_cli from user";
//    query2.prepare(que);
//    query2.exec();
//    query2.next();
//    val1=query2.value(0).toString();
//    qDebug()<<"val1 :"<<val1;

//    que1="select id_clt from client where email=:useremail";
//    query3.prepare(que1);
//    query3.bindValue(":useremail",val1);
//    query3.exec();
//    query3.next();
//    val2=query3.value(0).toString();
//    qDebug()<<"val2 :"<<val2;

//    que2="select id_chamb from chambre where nomchambre=:nomchambre";
//    query4.prepare(que2);
//    query4.bindValue(":nomchambre",nomchambre);
//    query4.exec();
//    query4.next();
//    val3=query4.value(0).toString();
//    qDebug()<<"val3 :"<<val3;
//    qDebug()<<"date_arrivee :"<<date_arrivee;
//    qDebug()<<"date_depart :"<<date_depart;

////    QDate selectedDate_arrivee = QDate::fromString(date_arrivee, "yyyy-MM-dd");
////    QDate selectedDate_depart = QDate::fromString(date_depart, "yyyy-MM-dd");

////    int joursDifference = selectedDate_arrivee.daysTo(selectedDate_depart);
////    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;

//    qint64 joursDifference = date_arrivee.daysTo(date_depart);

//    // Conversion explicite de qint64 à int
//    int joursDifferenceInt;
//    joursDifferenceInt= static_cast<int>(joursDifference);

//    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;
////int que5;
//    que4="select id_type from chambre where nomchambre = :nomchambre";
//    query6.prepare(que4);
//    query6.bindValue(":nomchambre",nomchambre);
//    query6.exec();
//    query6.next();
//    val5=query6.value(0).toString();
//    qDebug()<<"val5 :"<<val5;

//    que3="select tarif from typechambre where id_type=:val5";
//    query5.prepare(que3);
//    query5.bindValue(":val5",val5.toInt());
//    query5.exec();
//    query5.next();
//    val4=query5.value(0).toString();
//    qDebug()<<"val4 :"<<val4;

//    prix=joursDifferenceInt*val4.toInt();
////    val4=prix;
//    qDebug()<<"prix :"<<prix;

//    query1.prepare("insert into reservation (date_arrivee,date_depart,id_clt,id_chamb,prix_total) values('"+date_arrivee1+"','"+date_depart1+"','"+val2+"','"+val3+"',:prix)");
//    query1.bindValue(":prix",prix);
//    query1.exec();

//    database.close();
//    accept();
//}

////void reservation::on_confirme_clicked()
////{
////    QString date_depart = ui->date_depart->text();
////    QString date_arrivee = ui->date_arrivee->text();
////    QString nomchambre = ui->chambre->currentText();

////    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
////    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

////    if (!database.open())
////    {
////        qDebug()<< "Erreur : impossible d'ouvrir la base de données";
////        return;
////    }
////    qDebug()<<"Database est ouverte!";

////    // Mettez tous les objets QSqlQuery dans le même bloc avec la base de données
////    QSqlQuery query(database);

////    // Mettez à jour la disponibilité de la chambre
////    query.prepare("UPDATE chambre SET dispo=1 WHERE nomchambre=:nomchambre");
////    query.bindValue(":nomchambre", nomchambre);
////    if (!query.exec())
////    {
////        qDebug()<<"Erreur lors de la mise à jour de la disponibilité de la chambre :"<<query.lastError().text();
////        database.close();
////        return;
////    }

////    // Récupérez l'email de l'utilisateur
////    query.prepare("SELECT email FROM user");
////    if (!query.exec() || !query.next())
////    {
////        qDebug()<<"Erreur lors de la récupération de l'email de l'utilisateur :"<<query.lastError().text();
////        database.close();
////        return;
////    }
////    QString userEmail = query.value(0).toString();

////    // Récupérez l'id du client en utilisant l'email
////    query.prepare("SELECT id_clt FROM client WHERE email=:useremail");
////    query.bindValue(":useremail", userEmail);
////    if (!query.exec() || !query.next())
////    {
////        qDebug()<<"Erreur lors de la récupération de l'id du client :"<<query.lastError().text();
////        database.close();
////        return;
////    }
////    QString clientId = query.value(0).toString();

////    // Récupérez l'id de la chambre en utilisant le nom de la chambre
////    query.prepare("SELECT id_chamb FROM chambre WHERE nomchambre=:nomchambre");
////    query.bindValue(":nomchambre", nomchambre);
////    if (!query.exec() || !query.next())
////    {
////        qDebug()<<"Erreur lors de la récupération de l'id de la chambre :"<<query.lastError().text();
////        database.close();
////        return;
////    }
////    QString chambreId = query.value(0).toString();

////    QMessageBox::information(this, "Informations", "Id Client : " + clientId + "\nId Chambre : " + chambreId);

////    // Insérez la réservation dans la table reservation
////    query.prepare("INSERT INTO reservation (date_arrivee, date_depart, id_clt, id_chamb) VALUES (:date_arrivee, :date_depart, :id_clt, :id_chamb)");
////    query.bindValue(":date_arrivee", date_arrivee);
////    query.bindValue(":date_depart", date_depart);
////    query.bindValue(":id_clt", clientId);
////    query.bindValue(":id_chamb", chambreId);
////    if (!query.exec())
////    {
////        qDebug()<<"Erreur lors de l'insertion de la réservation :"<<query.lastError().text();
////        database.close();
////        return;
////    }

////    database.close();
////    accept();
////}


#include "reservation.h"
#include "ui_reservation.h"

reservation::reservation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::reservation)
{
    ui->setupUi(this);

//    affichagetableview();
}

reservation::~reservation()
{
    delete ui;

    delete mod;
}

void reservation::on_load_clicked(){
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

        if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
        {
            qDebug()<<"Database file exists";
        }
        else
        {
            qDebug()<<"erreur Database";
            return;
        }

        if(!database.open())
        {
            qDebug()<< "Erreur : impossible d'ouvrire Database";
        }
        else
        {
            qDebug()<<"Database est ouvert!";
        }

        QSqlQuery query, queryType;

        query = QSqlQuery(database);
        queryType = QSqlQuery(database);

        query.prepare("select nomchambre, id_type from chambre where dispo=0");
        query.exec();

        QSqlQueryModel *modelChambre = new QSqlQueryModel;
        modelChambre->setQuery(query);


        int ligne = 0;
        query.exec("select count(*) from chambre");
        while (query.next()) {
            ligne = query.value(0).toInt();
        }

        mod = new QStandardItemModel(ligne, 2);
        int row = 0;
        query.exec("select nomchambre, id_type from chambre");
        while (query.next()) {
            for (int j = 0; j < 2; j++) {
                QStandardItem *item = new QStandardItem(query.value(j).toString());
                mod->setItem(row, j, item);

                if (j == 1) {
                    // Si la colonne est celle des types de chambre, récupérer le nom du type
                    int typeId = query.value(1).toInt();
                    queryType.prepare("select nomtype from typechambre where id_type=:id");
                    queryType.bindValue(":id", typeId);
                    queryType.exec();

                    if (queryType.next()) {
                        QStandardItem *typeItem = new QStandardItem(queryType.value(0).toString());
                        mod->setItem(row, 1, typeItem);
                    }
                }
            }
            row++;
        }

        mod->setHeaderData(0, Qt::Horizontal, "Nom Chambre");
        mod->setHeaderData(1, Qt::Horizontal, "Type Chambre");
        ui->tableView->setModel(mod);

        ui->chambre->setModel(modelChambre);

        qDebug()<<"last error :"<<query.lastError().text();
        database.close();
}

//void reservation::on_load_clicked(){
//        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
//        database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

//        if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db"))
//        {
//            qDebug()<<"Database file exists";
//        }
//        else
//        {
//            qDebug()<<"erreur Database";
//            return;
//        }

//        if(!database.open())
//        {
//            qDebug()<< "Erreur : impossible d'ouvrire Database";
//        }
//        else
//        {
//            qDebug()<<"Database est ouvert!";
//        }

//        QSqlQuery query;

//        query = QSqlQuery(database);

//        query.prepare("select nomchambre from chambre where dispo=0");
//        query.exec();
//        QSqlQueryModel *modelChambre = new QSqlQueryModel;
//        modelChambre->setQuery(query);
//        ui->chambre->setModel(modelChambre);

//        qDebug()<<"last error :"<<query.lastError().text();
//        database.close();
//}

//void reservation::affichagetableview()
//{
//    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
//    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

//    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db"))
//    {
//        qDebug()<<"Database file exists";
//    }
//    else
//    {
//        qDebug()<<"erreur Database";
//        return;
//    }

//    if(!database.open())
//    {
//        qDebug()<< "Erreur : impossible d'ouvrire Database";
//    }
//    else
//    {
//        qDebug()<<"Database est ouvert!";
//    }

//    QSqlQuery query/,query1/;

//    query = QSqlQuery(database);
////    query1 = QSqlQuery(database);

//    query.prepare("select nomchambre from chambre where dispo=0");
//    query.exec();

////    query1.prepare("select nomchambre,id_type from chambre where dispo=0");
////    query1.exec();

//    QSqlQueryModel *modelChambre = new QSqlQueryModel;
////    QSqlQueryModel *modele = new QSqlQueryModel;

//    modelChambre->setQuery(query);
////    modele->setQuery(query1);


//    QSqlQuery req,req2;
//        int ligne (0);
//        req.exec("select count(*) from chambre");
//        while (req.next()) {
//            ligne=req.value(0).toInt();
//        }


//        mod = new QStandardItemModel (ligne, 2);
//        int row(0),i;
//        req.exec("select nomchambre,id_type from chambre");
//        //req.next();

//        /*i=req.value(1).toInt();

//        req2.exec("select nomtype from typechambre where id_type=:i  ");
//        req2.bindValue(":i",i);
//        req2.next();*/

//        while (req.next()) {

//            for (int j=0 ;j<2;j++) {



//                 QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
//                 mod->setItem(row,j,item);
//                 if(j==1){

//                     i=req.value(1).toInt();
//                     req2.bindValue(":i",i);
//                     req2.exec("select nomtype from typechambre where id_type=:i  ");


//                     req2.next();




//                 QStandardItem *item = new QStandardItem(req2.value (0).toString()) ;


//                 mod->setItem(row,1,item);
//                 }
//                if(j==0){



//                QStandardItem *item = new QStandardItem(req.value (j).toString()) ;

//                mod->setItem(row,j,item);


//                }
//            }
//            row++;

//        }

//              //QTableView *Ui_checkout::;

//            mod->setHeaderData (0, Qt::Horizontal, "Nom Chmabre");
//            mod->setHeaderData (1, Qt::Horizontal, "Type Chambre");
//            ui->tableView->setModel(mod);


//    ui->chambre->setModel(modelChambre);

//    qDebug()<<"last error :"<<query.lastError().text();
//    database.close();

//}

//void reservation::affichagetableview()
//{
//    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
//    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

//    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db"))
//    {
//        qDebug()<<"Database file exists";
//    }
//    else
//    {
//        qDebug()<<"erreur Database";
//        return;
//    }

//    if(!database.open())
//    {
//        qDebug()<< "Erreur : impossible d'ouvrire Database";
//    }
//    else
//    {
//        qDebug()<<"Database est ouvert!";
//    }

//    QSqlQuery query, queryType;

//    query = QSqlQuery(database);
//    queryType = QSqlQuery(database);

//    query.prepare("select nomchambre, id_type from chambre where dispo=0");
//    query.exec();

//    QSqlQueryModel *modelChambre = new QSqlQueryModel;
//    modelChambre->setQuery(query);


//    int ligne = 0;
//    query.exec("select count(*) from chambre");
//    while (query.next()) {
//        ligne = query.value(0).toInt();
//    }

//    mod = new QStandardItemModel(ligne, 2);
//    int row = 0;
//    query.exec("select nomchambre, id_type from chambre");
//    while (query.next()) {
//        for (int j = 0; j < 2; j++) {
//            QStandardItem *item = new QStandardItem(query.value(j).toString());
//            mod->setItem(row, j, item);

//            if (j == 1) {
//                // Si la colonne est celle des types de chambre, récupérer le nom du type
//                int typeId = query.value(1).toInt();
//                queryType.prepare("select nomtype from typechambre where id_type=:id");
//                queryType.bindValue(":id", typeId);
//                queryType.exec();

//                if (queryType.next()) {
//                    QStandardItem *typeItem = new QStandardItem(queryType.value(0).toString());
//                    mod->setItem(row, 1, typeItem);
//                }
//            }
//        }
//        row++;
//    }

//    mod->setHeaderData(0, Qt::Horizontal, "Nom Chambre");
//    mod->setHeaderData(1, Qt::Horizontal, "Type Chambre");
//    ui->tableView->setModel(mod);

//    ui->chambre->setModel(modelChambre);

//    qDebug()<<"last error :"<<query.lastError().text();
//    database.close();
//}


void reservation::on_confirme_clicked()
{
    QString date_depart1 = ui->date_depart->text();
    QString date_arrivee1 = ui->date_arrivee->text();
    QString nomchambre = ui->chambre->currentText();
    QDate date_depart=ui->date_depart->date();
    QDate date_arrivee = ui->date_arrivee->date();

    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
    {
        qDebug()<<"Database file exists";
    }
    else
    {
        qDebug()<<"erreur Database";
        return;
    }

    if(!database.open())
    {
        qDebug()<< "Erreur : impossible d'ouvrire Database";
    }
    else
    {
        qDebug()<<"Database est ouvert!";
    }

    QSqlQuery query;
    query = QSqlQuery(database);
    query.prepare("update chambre set dispo=1 where nomchambre=:nomchambre");
    query.bindValue(":nomchambre",nomchambre);
    query.exec();

    QSqlQuery query1,query2,query3,query4,query5,query6;
    query1 = QSqlQuery(database);
    query2 = QSqlQuery(database);
    query3 = QSqlQuery(database);
    query4 = QSqlQuery(database);
    query5 = QSqlQuery(database);
    query6 = QSqlQuery(database);

    QString val1,que,que1,que2,val2,val3,que3,val4,val5,que4;
    int prix;

    que="select emaili_cli from user";
    query2.prepare(que);
    query2.exec();
    query2.next();
    val1=query2.value(0).toString();
    qDebug()<<"val1 :"<<val1;

    que1="select id_clt from client where email=:useremail";
    query3.prepare(que1);
    query3.bindValue(":useremail",val1);
    query3.exec();
    query3.next();
    val2=query3.value(0).toString();
    qDebug()<<"val2 :"<<val2;

    que2="select id_chamb from chambre where nomchambre=:nomchambre";
    query4.prepare(que2);
    query4.bindValue(":nomchambre",nomchambre);
    query4.exec();
    query4.next();
    val3=query4.value(0).toString();
    qDebug()<<"val3 :"<<val3;
    qDebug()<<"date_arrivee :"<<date_arrivee;
    qDebug()<<"date_depart :"<<date_depart;

//    QDate selectedDate_arrivee = QDate::fromString(date_arrivee, "yyyy-MM-dd");
//    QDate selectedDate_depart = QDate::fromString(date_depart, "yyyy-MM-dd");

//    int joursDifference = selectedDate_arrivee.daysTo(selectedDate_depart);
//    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;

    qint64 joursDifference = date_arrivee.daysTo(date_depart);

    // Conversion explicite de qint64 à int
    int joursDifferenceInt;
    joursDifferenceInt= static_cast<int>(joursDifference);

    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;
//int que5;
    que4="select id_type from chambre where nomchambre = :nomchambre";
    query6.prepare(que4);
    query6.bindValue(":nomchambre",nomchambre);
    query6.exec();
    query6.next();
    val5=query6.value(0).toString();
    qDebug()<<"val5 :"<<val5;

    que3="select tarif from typechambre where id_type=:val5";
    query5.prepare(que3);
    query5.bindValue(":val5",val5.toInt());
    query5.exec();
    query5.next();
    val4=query5.value(0).toString();
    qDebug()<<"val4 :"<<val4;

    prix=joursDifferenceInt*val4.toInt();
//    val4=prix;
    qDebug()<<"prix :"<<prix;

    query1.prepare("insert into reservation (date_arrivee,date_depart,id_clt,id_chamb,prix_total) values('"+date_arrivee1+"','"+date_depart1+"','"+val2+"','"+val3+"',:prix)");
    query1.bindValue(":prix",prix);
    query1.exec();

    database.close();
    accept();
}

//void reservation::on_confirme_clicked()
//{
//    QString date_depart = ui->date_depart->text();
//    QString date_arrivee = ui->date_arrivee->text();
//    QString nomchambre = ui->chambre->currentText();

//    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
//    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qtpr/qtdb/hotel.db");

//    if (!database.open())
//    {
//        qDebug()<< "Erreur : impossible d'ouvrir la base de données";
//        return;
//    }
//    qDebug()<<"Database est ouverte!";

//    // Mettez tous les objets QSqlQuery dans le même bloc avec la base de données
//    QSqlQuery query(database);

//    // Mettez à jour la disponibilité de la chambre
//    query.prepare("UPDATE chambre SET dispo=1 WHERE nomchambre=:nomchambre");
//    query.bindValue(":nomchambre", nomchambre);
//    if (!query.exec())
//    {
//        qDebug()<<"Erreur lors de la mise à jour de la disponibilité de la chambre :"<<query.lastError().text();
//        database.close();
//        return;
//    }

//    // Récupérez l'email de l'utilisateur
//    query.prepare("SELECT email FROM user");
//    if (!query.exec() || !query.next())
//    {
//        qDebug()<<"Erreur lors de la récupération de l'email de l'utilisateur :"<<query.lastError().text();
//        database.close();
//        return;
//    }
//    QString userEmail = query.value(0).toString();

//    // Récupérez l'id du client en utilisant l'email
//    query.prepare("SELECT id_clt FROM client WHERE email=:useremail");
//    query.bindValue(":useremail", userEmail);
//    if (!query.exec() || !query.next())
//    {
//        qDebug()<<"Erreur lors de la récupération de l'id du client :"<<query.lastError().text();
//        database.close();
//        return;
//    }
//    QString clientId = query.value(0).toString();

//    // Récupérez l'id de la chambre en utilisant le nom de la chambre
//    query.prepare("SELECT id_chamb FROM chambre WHERE nomchambre=:nomchambre");
//    query.bindValue(":nomchambre", nomchambre);
//    if (!query.exec() || !query.next())
//    {
//        qDebug()<<"Erreur lors de la récupération de l'id de la chambre :"<<query.lastError().text();
//        database.close();
//        return;
//    }
//    QString chambreId = query.value(0).toString();

//    QMessageBox::information(this, "Informations", "Id Client : " + clientId + "\nId Chambre : " + chambreId);

//    // Insérez la réservation dans la table reservation
//    query.prepare("INSERT INTO reservation (date_arrivee, date_depart, id_clt, id_chamb) VALUES (:date_arrivee, :date_depart, :id_clt, :id_chamb)");
//    query.bindValue(":date_arrivee", date_arrivee);
//    query.bindValue(":date_depart", date_depart);
//    query.bindValue(":id_clt", clientId);
//    query.bindValue(":id_chamb", chambreId);
//    if (!query.exec())
//    {
//        qDebug()<<"Erreur lors de l'insertion de la réservation :"<<query.lastError().text();
//        database.close();
//        return;
//    }

//    database.close();
//    accept();
//}
