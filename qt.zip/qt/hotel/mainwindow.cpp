#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ptrloginemp = new loginemp;
    ptrinscription = new inscription;
}

MainWindow::~MainWindow()
{
    delete ui;

    delete ptrloginemp;
    delete ptrinscription;
}

void MainWindow::on_employer_clicked()
{
    ptrloginemp->show();
}

void MainWindow::on_client_clicked()
{
    ptrinscription->show();
}
