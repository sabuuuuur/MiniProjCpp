#include "cludt.h"
#include "ui_cludt.h"

cludt::cludt(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::cludt)
{
    ui->setupUi(this);

}

cludt::~cludt()
{
    delete ui;

}

void cludt::on_pushButton_clicked()
{


    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
        qDebug() << "Database file does not exist";
        return;
    }

    if (!database.open()) {
        qDebug() << "Erreur : impossible d'ouvrir la base de données";
        return;
    }



    QString que6,que7,res3,qu;
    QSqlQuery req,query6,query7;


    /*que6="SELECT emaili_cli FROM user";
    query6.prepare(que6);
    //query6.bindValue(":res2",res2);
    query6.exec();
    query6.next();

    res3=query6.value(0).toString();

    qDebug()<<"Halo"<<res3;

    int res2;

    que7="SELECT id_clt FROM client WHERE email=:res3 ";
    query7.prepare(que7);
    query7.bindValue(":res3",res3);
    query7.exec();
    query7.next();

    res2=query7.value(0).toInt();

    qDebug()<<"Halo"<<res2;*/



    int ligne (0);
    qu="select count(*) from client ";
    req.prepare(qu);
    //req.bindValue(":res2",res2);
    req.exec();

    //req.exec("select count(*) from client WHERE id_clt= :res2");
    while (req.next()) {
        ligne=req.value(0).toInt();
    }


    mod2 = new QStandardItemModel (ligne, 8);
    int row(0);

    //req.exec("select id_res, date_arrivee, date_depart, id_clt, id_chamb,id_fact from reservation");
    qu="select id_clt, nom, prenom, email, tel,date_naissance ,sexe ,password from client ";
    req.prepare(qu);
   // req.bindValue(":res2",res2);
    req.exec();
    while (req.next()) {

        for (int j=0 ;j<8;j++) {

            QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
            mod2->setItem(row,j,item);
        }
        row++;

    }

          //QTableView *Ui_checkout::;

        mod2->setHeaderData (0, Qt::Horizontal, "N°client");
        mod2->setHeaderData (1, Qt::Horizontal, "Nom client");
        mod2->setHeaderData (2, Qt::Horizontal, "Prenom client");
        mod2->setHeaderData (3, Qt::Horizontal, "Email client");
        mod2->setHeaderData (4, Qt::Horizontal, "Tel client");
         mod2->setHeaderData (5, Qt::Horizontal, "Date naissance client");
         mod2->setHeaderData (6, Qt::Horizontal, "Sexe client");
         mod2->setHeaderData (7, Qt::Horizontal, "Password client");
        ui->tableView->setModel(mod2);




}

void cludt::on_pushButton_2_clicked()
{

    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString email = ui->email->text();
    QString datenaissance = ui->datenaissance->text();
    QString tel = ui->tel->text();
    QString sexe = ui->sexe->currentText();
    QString password = ui->password->text();
    QString eyed=ui->lineEdit_3->text();

    QString nom2 ;
    QString prenom2 ;
    QString email2;
    QString datenaissance2 ;
    QString tel2;
    QString sexe2;
    QString password2;
    int eyed2;
    QString qu;



    //QString eyed=ui->lineEdit_3->text();

    //usermail=ui->email->text();

    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
    {
        qDebug()<<"Database file exists";
    }
    else
    {
        qDebug()<<"erreur Database";
        return;
    }

    if(!database.open())
    {
        qDebug()<< "Erreur : impossible d'ouvrire Database";
    }
    else
    {
        qDebug()<<"Database est ouvert!";
    }
    QSqlQuery ques;
    ques = QSqlQuery(database);
        eyed2=eyed.toInt();

        qDebug()<<"Nom : "<<nom<<" Prenom : "<<prenom<<" email : "<<email<<"date de naissance : "<<datenaissance<<" sexe :"<<sexe<<" password :"<<password;
        qDebug()<<"m:"<<eyed2;

        if(nom.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            nom2=ques.value(1).toString();


            qDebug()<<"m2:"<<nom2;


        }else {


            nom2 = ui->nom->text();

        }

        if(prenom.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            prenom2=ques.value(2).toString();


            qDebug()<<"m2:"<<prenom2;


        }else {


            prenom2 = ui->prenom->text();

        }

        if(email.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            email2=ques.value(3).toString();


            qDebug()<<"m2:"<<email2;


        }else {


            email2 = ui->email->text();

        }

        if(tel.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            tel2=ques.value(4).toString();


            qDebug()<<"m2:"<<tel2;


        }else {


            tel2 = ui->tel->text();

        }

        if(datenaissance.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            datenaissance2=ques.value(5).toString();


            qDebug()<<"m2:"<<datenaissance2;


        }else {


            datenaissance2 = ui->datenaissance->text();

        }

        if(sexe.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            sexe2=ques.value(6).toString();


            qDebug()<<"m2:"<<sexe2;


        }else {


            sexe2 = ui->sexe->currentText();

        }

        if(password.isEmpty()){

            qu="SELECT * FROM client WHERE id_clt=:eyed2";
            ques.prepare(qu);
            ques.bindValue(":eyed2",eyed2);
            ques.exec();ques.next();
            password2=ques.value(7).toString();


            qDebug()<<"m2:"<<password2;


        }else {


            password2 = ui->password->text();

        }







        QSqlQuery query;
        QString que;
        query = QSqlQuery(database);



        QSqlQuery query3,query4,query5;

       /* que4="DELETE FROM client WHERE id_clt = :eyed; ";
        query4.prepare(que4);
        query4.bindValue(":eyed",eyed);
        query4.exec();
        query4.next();*/

        //(nom,prenom,email,date_naissance,tel,sexe,password) values('"+nom+"','"+prenom+"','"+email+"','"+datenaissance+"','"+tel+"','"+sexe+"','"+password+"')

        que="UPDATE client   SET nom = '"+nom2+"', prenom= '"+prenom2+"' , email= '"+email2+"', date_naissance= '"+datenaissance2+"', tel= '"+tel2+"', sexe= '"+sexe2+"', password= '"+password2+"'  WHERE id_clt = :eyed2 ";
        query.prepare(que);
        query.bindValue(":eyed2",eyed2);
        query.exec();
        query.next();
        qDebug()<<"last error :"<<query.lastError().text();
        database.close();


    }







