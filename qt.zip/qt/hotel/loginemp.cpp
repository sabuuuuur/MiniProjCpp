#include "loginemp.h"
#include "ui_loginemp.h"

loginemp::loginemp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::loginemp)
{
    ui->setupUi(this);

    ptremphome = new emphome();
}

loginemp::~loginemp()
{
    delete ui;

    delete ptremphome;
}

void loginemp::on_connect_clicked()
{
    QString code = ui->code->text();

    if(code.isEmpty()){
        QMessageBox::information(this,"Attention","Vous devez remplir le code");
    }else {
        if(code == "7532"){
            qDebug() << "Authentication successful";
            ptremphome->show();
            loginemp::hide();
        }else {
            QMessageBox::information(this,"Attention","Votre code n'est pas valide");
        }
    }
}
