#include "inscription.h"
#include "ui_inscription.h"

inscription::inscription(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::inscription)
{
    ui->setupUi(this);

    ptrlogin = new login();
}

inscription::~inscription()
{
    delete ui;

    delete ptrlogin;
}

void inscription::on_registre_clicked()
{
    QString nom = ui->nom->text();
    QString prenom = ui->prenom->text();
    QString email = ui->email->text();
    QString datenaissance = ui->datenaissance->text();
    QString tel = ui->tel->text();
    QString sexe = ui->sexe->currentText();
    QString password = ui->password->text();


    if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || datenaissance.isEmpty() || tel.isEmpty() || password.isEmpty()) {
        QMessageBox::information(this,"Attention","Vous devez remplir tous les champs !!");
    } else {
        qDebug()<<"Nom : "<<nom<<" Prenom : "<<prenom<<" email : "<<email<<"date de naissance : "<<datenaissance<<" sexe :"<<sexe<<" password :"<<password;

        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

        if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
        {
            qDebug()<<"Database file exists";
        }
        else
        {
            qDebug()<<"erreur Database";
            return;
        }

        if(!database.open())
        {
            qDebug()<< "Erreur : impossible d'ouvrire Database";
        }
        else
        {
            qDebug()<<"Database est ouvert!";
        }

        QSqlQuery query;
        query = QSqlQuery(database);

        query.prepare("insert into client (nom,prenom,email,date_naissance,tel,sexe,password) values('"+nom+"','"+prenom+"','"+email+"','"+datenaissance+"','"+tel+"','"+sexe+"','"+password+"')");
        query.exec();
        qDebug()<<"last error :"<<query.lastError().text();
        database.close();

        ptrlogin->show();
    }
}

void inscription::on_login_clicked()
{
    ptrlogin->show();
}
