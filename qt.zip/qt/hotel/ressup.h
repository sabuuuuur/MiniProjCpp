#ifndef RESSUP_H
#define RESSUP_H

#include <QDialog>
#include "database.h"
#include<QStandardItemModel>

namespace Ui {
class ressup;
}

class ressup : public QDialog
{
    Q_OBJECT

public:
    explicit ressup(QWidget *parent = nullptr);
    ~ressup();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::ressup *ui;
    QStandardItemModel *mod2;
};

#endif // RESSUP_H
