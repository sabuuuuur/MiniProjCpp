#ifndef ANNULER_H
#define ANNULER_H

#include <QDialog>

#include "database.h"
#include<QStandardItemModel>

namespace Ui {
class annuler;
}

class annuler : public QDialog
{
    Q_OBJECT

public:
    explicit annuler(QWidget *parent = nullptr);
    ~annuler();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::annuler *ui;

    QStandardItemModel *mod2;
};

#endif // ANNULER_H
