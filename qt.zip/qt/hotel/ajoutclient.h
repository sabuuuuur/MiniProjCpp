#ifndef AJOUTCLIENT_H
#define AJOUTCLIENT_H

#include <QDialog>

#include "database.h"

namespace Ui {
class ajoutclient;
}

class ajoutclient : public QDialog
{
    Q_OBJECT

public:
    explicit ajoutclient(QWidget *parent = nullptr);
    ~ajoutclient();

private slots:
    void on_registre_clicked();

private:
    Ui::ajoutclient *ui;
};

#endif // AJOUTCLIENT_H
