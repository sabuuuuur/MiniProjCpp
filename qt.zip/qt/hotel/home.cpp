#include "home.h"
#include "ui_home.h"

home::home(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::home)
{
    ui->setupUi(this);

    ptrreservation = new reservation();
    ptrdisponibilite = new disponibilite();
    ptrannuler =new annuler();
    ptrcheckout =new checkout();
}

home::~home()
{
    delete ui;

    delete ptrreservation;
    delete ptrdisponibilite;
    delete ptrannuler;
    delete ptrcheckout;
}

void home::on_reservation_clicked()
{
    ptrreservation->show();
}

void home::on_logout_clicked()
{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
                database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

                if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
                    qDebug() << "Database file does not exist";
                    return;
                }

                if (!database.open()) {
                    qDebug() << "Erreur : impossible d'ouvrir la base de données";
                    return;
                }
        QSqlQuery query2;
        query2 = QSqlQuery(database);

       query2.prepare("DELETE FROM user");

       query2.exec();
       home::hide();
       //accept();
}

void home::on_Disponibilite_clicked()
{
    ptrdisponibilite->show();
}

void home::on_CheckOut_clicked()
{
    ptrcheckout->show();
}

void home::on_annulation_clicked()
{
    ptrannuler->show();
}
