#ifndef AJOUTRESERVATION_H
#define AJOUTRESERVATION_H

#include <QDialog>

#include "database.h"

namespace Ui {
class ajoutreservation;
}

class ajoutreservation : public QDialog
{
    Q_OBJECT

public:
    explicit ajoutreservation(QWidget *parent = nullptr);
    ~ajoutreservation();

private slots:
    void on_load_clicked();

    void on_confirme_clicked();

private:
    Ui::ajoutreservation *ui;

    QStandardItemModel *mod;
};

#endif // AJOUTRESERVATION_H
