#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "loginemp.h"
#include "inscription.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_employer_clicked();

    void on_client_clicked();

private:
    Ui::MainWindow *ui;

    loginemp *ptrloginemp;
    inscription *ptrinscription;
};

#endif // MAINWINDOW_H
