#include "ajoutreservation.h"
#include "ui_ajoutreservation.h"

ajoutreservation::ajoutreservation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajoutreservation)
{
    ui->setupUi(this);
}

ajoutreservation::~ajoutreservation()
{
    delete ui;

    delete mod;
}

void ajoutreservation::on_load_clicked()
{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
    {
        qDebug()<<"Database file exists";
    }
    else
    {
        qDebug()<<"erreur Database";
        return;
    }

    if(!database.open())
    {
        qDebug()<< "Erreur : impossible d'ouvrire Database";
    }
    else
    {
        qDebug()<<"Database est ouvert!";
    }

    QSqlQuery query, queryType;

    query = QSqlQuery(database);
    queryType = QSqlQuery(database);

    query.prepare("select nomchambre, id_type from chambre where dispo=0");
    query.exec();

    QSqlQueryModel *modelChambre = new QSqlQueryModel;
    modelChambre->setQuery(query);


    int ligne = 0;
    query.exec("select count(*) from chambre");
    while (query.next()) {
        ligne = query.value(0).toInt();
    }

    mod = new QStandardItemModel(ligne, 2);
    int row = 0;
    query.exec("select nomchambre, id_type from chambre");
    while (query.next()) {
        for (int j = 0; j < 2; j++) {
            QStandardItem *item = new QStandardItem(query.value(j).toString());
            mod->setItem(row, j, item);

            if (j == 1) {
                // Si la colonne est celle des types de chambre, récupérer le nom du type
                int typeId = query.value(1).toInt();
                queryType.prepare("select nomtype from typechambre where id_type=:id");
                queryType.bindValue(":id", typeId);
                queryType.exec();

                if (queryType.next()) {
                    QStandardItem *typeItem = new QStandardItem(queryType.value(0).toString());
                    mod->setItem(row, 1, typeItem);
                }
            }
        }
        row++;
    }

    mod->setHeaderData(0, Qt::Horizontal, "Nom Chambre");
    mod->setHeaderData(1, Qt::Horizontal, "Type Chambre");
    ui->tableView->setModel(mod);

    ui->chambre->setModel(modelChambre);

    qDebug()<<"last error :"<<query.lastError().text();
    database.close();
}

void ajoutreservation::on_confirme_clicked()
{
    QString date_depart1 = ui->date_depart->text();
    QString date_arrivee1 = ui->date_arrivee->text();
    QString nomchambre = ui->chambre->currentText();
    QDate date_depart=ui->date_depart->date();
    QDate date_arrivee = ui->date_arrivee->date();

    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db"))
    {
        qDebug()<<"Database file exists";
    }
    else
    {
        qDebug()<<"erreur Database";
        return;
    }

    if(!database.open())
    {
        qDebug()<< "Erreur : impossible d'ouvrire Database";
    }
    else
    {
        qDebug()<<"Database est ouvert!";
    }

    QSqlQuery query;
    query = QSqlQuery(database);
    query.prepare("update chambre set dispo=1 where nomchambre=:nomchambre");
    query.bindValue(":nomchambre",nomchambre);
    query.exec();

    QSqlQuery query1,query2,query3,query4,query5,query6;
    query1 = QSqlQuery(database);
    query2 = QSqlQuery(database);
    query3 = QSqlQuery(database);
    query4 = QSqlQuery(database);
    query5 = QSqlQuery(database);
    query6 = QSqlQuery(database);

    QString val1,que,que1,que2,val2,val3,val4,val5,que3,que4;
//    int ;

    que="select emaili_cli from user";
    query2.prepare(que);
    query2.exec();
    query2.next();
    val1=query2.value(0).toString();
    qDebug()<<"val1 :"<<val1;

    que1="select id_clt from client where email=:useremail";
    query3.prepare(que1);
    query3.bindValue(":useremail",val1);
    query3.exec();
    query3.next();
    val2=query3.value(0).toString();
    qDebug()<<"val2 :"<<val2;

    que2="select id_chamb from chambre where nomchambre=:nomchambre";
    query4.prepare(que2);
    query4.bindValue(":nomchambre",nomchambre);
    query4.exec();
    query4.next();
    val3=query4.value(0).toString();
    qDebug()<<"val3 :"<<val3;

//    QDate selectedDate_arrivee = QDate::fromString(date_arrivee, "yyyy-MM-dd");
//    QDate selectedDate_depart = QDate::fromString(date_depart, "yyyy-MM-dd");

//    int joursDifference = selectedDate_arrivee.daysTo(selectedDate_depart);
//    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;

//    QDate selectedDate_arrivee = QDate::fromString(date_arrivee, "MM-dd-yyyy");
//    QDate selectedDate_depart = QDate::fromString(date_depart, "MM-dd-yyyy");

//    qint64 joursDifference = selectedDate_arrivee.daysTo(selectedDate_depart);

//    // Conversion explicite de qint64 à int
//    int joursDifferenceInt = static_cast<int>(joursDifference);

//    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;


//    query1.prepare("insert into reservation (date_arrivee,date_depart,id_clt,id_chamb) values('"+date_arrivee+"','"+date_depart+"','"+val2+"','"+val3+"')");
//    query1.exec();

//    database.close();
//    accept();

    qDebug()<<"date_arrivee :"<<date_arrivee;
    qDebug()<<"date_depart :"<<date_depart;

//    QDate selectedDate_arrivee = QDate::fromString(date_arrivee, "yyyy-MM-dd");
//    QDate selectedDate_depart = QDate::fromString(date_depart, "yyyy-MM-dd");

//    int joursDifference = selectedDate_arrivee.daysTo(selectedDate_depart);
//    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;

    qint64 joursDifference = date_arrivee.daysTo(date_depart);

    // Conversion explicite de qint64 à int
    int joursDifferenceInt;
    joursDifferenceInt= static_cast<int>(joursDifference);

    qDebug() << "La différence en jours entre les deux dates est : " << joursDifference;
//int que5;
    que4="select id_type from chambre where nomchambre = :nomchambre";
    query6.prepare(que4);
    query6.bindValue(":nomchambre",nomchambre);
    query6.exec();
    query6.next();
    val5=query6.value(0).toString();
    qDebug()<<"val5 :"<<val5;

    que3="select tarif from typechambre where id_type=:val5";
    query5.prepare(que3);
    query5.bindValue(":val5",val5.toInt());
    query5.exec();
    query5.next();
    val4=query5.value(0).toString();
    qDebug()<<"val4 :"<<val4;
    int prix;
    prix=joursDifferenceInt*val4.toInt();
//    val4=prix;
    qDebug()<<"prix :"<<prix;

    query1.prepare("insert into reservation (date_arrivee,date_depart,id_clt,id_chamb,prix_total) values('"+date_arrivee1+"','"+date_depart1+"','"+val2+"','"+val3+"',:prix)");
    query1.bindValue(":prix",prix);
    query1.exec();

    database.close();
    accept();
}
