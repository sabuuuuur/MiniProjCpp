#ifndef INSCRIPTION_H
#define INSCRIPTION_H

#include <QDialog>

#include "login.h"
#include "database.h"

namespace Ui {
class inscription;
}

class inscription : public QDialog
{
    Q_OBJECT

public:
    explicit inscription(QWidget *parent = nullptr);
    ~inscription();

private slots:
    void on_registre_clicked();

    void on_login_clicked();

private:
    Ui::inscription *ui;

    login *ptrlogin;
};

#endif // INSCRIPTION_H
