#ifndef EMPDISPONIBILITE_H
#define EMPDISPONIBILITE_H

#include <QDialog>

#include "database.h"

namespace Ui {
class empdisponibilite;
}

class empdisponibilite : public QDialog
{
    Q_OBJECT

public:
    explicit empdisponibilite(QWidget *parent = nullptr);
    ~empdisponibilite();

private slots:
    void on_affiche_clicked();

private:
    Ui::empdisponibilite *ui;

    QStandardItemModel *mod;
};

#endif // EMPDISPONIBILITE_H
