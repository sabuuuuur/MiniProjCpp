#ifndef CLAFF_H
#define CLAFF_H

#include <QDialog>
#include "database.h"
#include<QStandardItemModel>

namespace Ui {
class claff;
}

class claff : public QDialog
{
    Q_OBJECT

public:
    explicit claff(QWidget *parent = nullptr);
    ~claff();

private slots:
    void on_affiche_clicked();

private:
    Ui::claff *ui;
    QStandardItemModel *mod2;
};

#endif // CLAFF_H
