#ifndef CLSUP_H
#define CLSUP_H

#include <QDialog>
#include "database.h"
#include<QStandardItemModel>

namespace Ui {
class clsup;
}

class clsup : public QDialog
{
    Q_OBJECT

public:
    explicit clsup(QWidget *parent = nullptr);
    ~clsup();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::clsup *ui;
    QStandardItemModel *mod2;
};

#endif // CLSUP_H
