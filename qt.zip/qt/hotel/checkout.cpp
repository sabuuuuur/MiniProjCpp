#include "checkout.h"
#include "ui_checkout.h"
#include<QTableView>

checkout::checkout(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::checkout)
{
    ui->setupUi(this);
}

checkout::~checkout()
{
    delete ui;
}

void checkout::on_pushButton_2_clicked()
{

            QString que3,que4,que5,res;
            int res1;
            int eyed=ui->lineEdit_3->text().toInt();


            QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
            database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

            if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
                qDebug() << "Database file does not exist";
                return;
            }

            if (!database.open()) {
                qDebug() << "Erreur : impossible d'ouvrir la base de données";
                return;
            }

            QSqlQuery query3,query4,query5;

            que4="SELECT id_chamb FROM reservation WHERE id_res= :eyed ";
            query4.prepare(que4);
            query4.bindValue(":eyed",eyed);
            query4.exec();
            query4.next();

            res1=query4.value(0).toInt();

            qDebug()<<"Halo"<<res1;
            qDebug()<<"Halo"<<eyed;

            que5="UPDATE chambre SET dispo=0 WHERE id_chamb=:res1 ";
            query5.prepare(que5);
            query5.bindValue(":res1",res1);
            query5.exec();
            query5.next();

            //res1=query5.value(0).toInt();


              // QMessageBox::information(this,'validation','Checkout Done');


            /*que3="SELECT emaili_cli FROM reservation WHERE id_us=18  ";
            query3.exec(que3);
            query3.next();

            res=query3.value(0).toString();

            qDebug()<<"Halo"<<res;*/




    //query3 = QSqlQuery(database);

            /*query3.prepare("SELECT emaili_cli FROM user WHERE id_us='18'  ");
            query3.exec();
            query3.next();*/

}

void checkout::affres(){

    /*QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
        qDebug() << "Database file does not exist";
        return;
    }

    if (!database.open()) {
        qDebug() << "Erreur : impossible d'ouvrir la base de données";
        return;
    }



    QSqlQuery req;
    int ligne (0);
    req.exec("select count(*) from reservation");
    while (req.next()) {
        ligne=req.value(0).toInt();
    }


    mod = new QStandardItemModel (ligne, 7);
    int row(0);
    req.exec("select id_res, date_arrivee, date_depart, id_etat, id_clt, id_chamb,id_fact from reservation");
    while (req.next()) {

        for (int j=0 ;j<7;j++) {

            QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
            mod->setItem(row,j,item);
        }
        row++;

    }

        mod->setHeaderData (0, Qt::Horizontal, "N°rervation");
        mod->setHeaderData (1, Qt::Horizontal, "Date arrivee");
        mod->setHeaderData (2, Qt::Horizontal, "Date depart");
        mod->setHeaderData (3, Qt::Horizontal, "Etat chambre");
        mod->setHeaderData (4, Qt::Horizontal, "N° client");
        mod->setHeaderData (5, Qt::Horizontal, "N° chambre");
         mod->setHeaderData (6, Qt::Horizontal, "N° fact");
        //ui->tableView->setModel(mod);
         */

}
void checkout::on_pushButton_clicked()
{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
        qDebug() << "Database file does not exist";
        return;
    }

    if (!database.open()) {
        qDebug() << "Erreur : impossible d'ouvrir la base de données";
        return;
    }



    QString que6,que7,res3,qu;
    QSqlQuery req,query6,query7;


    que6="SELECT emaili_cli FROM user";
    query6.prepare(que6);
    //query6.bindValue(":res2",res2);
    query6.exec();
    query6.next();

    res3=query6.value(0).toString();

    qDebug()<<"Halo"<<res3;

    int res2;

    que7="SELECT id_clt FROM client WHERE email=:res3 ";
    query7.prepare(que7);
    query7.bindValue(":res3",res3);
    query7.exec();
    query7.next();

    res2=query7.value(0).toInt();

    qDebug()<<"Halo"<<res2;



    int ligne (0);
    qu="select count(*) from reservation WHERE id_clt= :res2";
    req.prepare(qu);
    req.bindValue(":res2",res2);
    req.exec();

    //req.exec("select count(*) from reservation WHERE id_clt= :res2");
    while (req.next()) {
        ligne=req.value(0).toInt();
    }


    mod = new QStandardItemModel (ligne, 6);
    int row(0);

    //req.exec("select id_res, date_arrivee, date_depart, id_clt, id_chamb,id_fact from reservation");
    qu="select id_res, date_arrivee, date_depart, id_clt, id_chamb,prix_total from reservation WHERE id_clt= :res2";
    req.prepare(qu);
    req.bindValue(":res2",res2);
    req.exec();
    while (req.next()) {

        for (int j=0 ;j<6;j++) {

            QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
            mod->setItem(row,j,item);
        }
        row++;

    }

          //QTableView *Ui_checkout::;

        mod->setHeaderData (0, Qt::Horizontal, "N°rervation");
        mod->setHeaderData (1, Qt::Horizontal, "Date arrivee");
        mod->setHeaderData (2, Qt::Horizontal, "Date depart");
        mod->setHeaderData (3, Qt::Horizontal, "N° client");
        mod->setHeaderData (4, Qt::Horizontal, "N° chambre");
         mod->setHeaderData (5, Qt::Horizontal, "N° fact");
        ui->tableView->setModel(mod);


}
