#ifndef HOME_H
#define HOME_H

#include <QDialog>

#include "database.h"
#include "reservation.h"
#include "disponibilite.h"
#include "annuler.h"
#include "checkout.h"

namespace Ui {
class home;
}

class home : public QDialog
{
    Q_OBJECT

public:
    explicit home(QWidget *parent = nullptr);
    ~home();

private slots:
    void on_reservation_clicked();

    void on_logout_clicked();

    void on_Disponibilite_clicked();

    void on_CheckOut_clicked();

    void on_annulation_clicked();

private:
    Ui::home *ui;

    reservation *ptrreservation;
    disponibilite *ptrdisponibilite;
    annuler *ptrannuler;
    checkout *ptrcheckout;

};

#endif // HOME_H
