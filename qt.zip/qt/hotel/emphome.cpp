#include "emphome.h"
#include "ui_emphome.h"

emphome::emphome(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::emphome)
{
    ui->setupUi(this);

    ptrempclient=new empclient;
    ptrempdisponibilite=new empdisponibilite;
    ptrempreservation=new empreservation;
}

emphome::~emphome()
{
    delete ui;

    delete ptrempclient;
    delete ptrempreservation;
    delete ptrempdisponibilite;
}

void emphome::on_logout_clicked()
{
    emphome::hide();
}

void emphome::on_client_clicked()
{
    ptrempclient->show();
}

void emphome::on_reservation_clicked()
{
    ptrempreservation->show();
}

void emphome::on_disponibilite_clicked()
{
    ptrempdisponibilite->show();
}
