#ifndef EMPRESERVATION_H
#define EMPRESERVATION_H

#include <QDialog>

#include "ajoutreservation.h"
#include "resaff.h"
#include "ressup.h"


namespace Ui {
class empreservation;
}

class empreservation : public QDialog
{
    Q_OBJECT

public:
    explicit empreservation(QWidget *parent = nullptr);
    ~empreservation();

private slots:
    void on_ajouter_clicked();

    void on_afficher_clicked();

    void on_annuler_clicked();

private:
    Ui::empreservation *ui;

    ajoutreservation *ptrajoutreservation;
    resaff *ptraff;
    ressup *ptrsup;
};

#endif // EMPRESERVATION_H
