#include "resaff.h"
#include "ui_resaff.h"

resaff::resaff(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::resaff)
{
    ui->setupUi(this);
}

resaff::~resaff()
{
    delete ui;
}

void resaff::on_affiche_clicked()
{

    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
        qDebug() << "Database file does not exist";
        return;
    }

    if (!database.open()) {
        qDebug() << "Erreur : impossible d'ouvrir la base de données";
        return;
    }



    QString que6,que7,res3,qu;
    QSqlQuery req,query6,query7;


    /*que6="SELECT emaili_cli FROM user";
    query6.prepare(que6);
    //query6.bindValue(":res2",res2);
    query6.exec();
    query6.next();

    res3=query6.value(0).toString();

    qDebug()<<"Halo"<<res3;

    int res2;

    que7="SELECT id_clt FROM client WHERE email=:res3 ";
    query7.prepare(que7);
    query7.bindValue(":res3",res3);
    query7.exec();
    query7.next();

    res2=query7.value(0).toInt();

    qDebug()<<"Halo"<<res2;*/



    int ligne (0);
    qu="select count(*) from reservation";
    req.prepare(qu);
    //req.bindValue(":res2",res2);
    req.exec();

    //req.exec("select count(*) from reservation WHERE id_clt= :res2");
    while (req.next()) {
        ligne=req.value(0).toInt();
    }


    mod2 = new QStandardItemModel (ligne, 6);
    int row(0);

    //req.exec("select id_res, date_arrivee, date_depart, id_clt, id_chamb,id_fact from reservation");
    qu="select id_res, date_arrivee, date_depart, id_clt, id_chamb,prix_total from reservation ";
    req.prepare(qu);
    //req.bindValue(":res2",res2);
    req.exec();
    while (req.next()) {

        for (int j=0 ;j<6;j++) {

            QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
            mod2->setItem(row,j,item);
        }
        row++;

    }

          //QTableView *Ui_checkout::;

        mod2->setHeaderData (0, Qt::Horizontal, "N°rervation");
        mod2->setHeaderData (1, Qt::Horizontal, "Date arrivee");
        mod2->setHeaderData (2, Qt::Horizontal, "Date depart");
        mod2->setHeaderData (3, Qt::Horizontal, "N° client");
        mod2->setHeaderData (4, Qt::Horizontal, "N° chambre");
         mod2->setHeaderData (5, Qt::Horizontal, "N° fact");
        ui->tableView->setModel(mod2);
}
