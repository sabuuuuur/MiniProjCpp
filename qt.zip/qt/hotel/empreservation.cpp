#include "empreservation.h"
#include "ui_empreservation.h"

empreservation::empreservation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::empreservation)
{
    ui->setupUi(this);

    ptrajoutreservation=new ajoutreservation;
    ptraff=new resaff;
    ptrsup=new ressup;
}

empreservation::~empreservation()
{
    delete ui;

    delete ptrajoutreservation;
    delete ptraff;
    delete ptrsup;
}

void empreservation::on_ajouter_clicked()
{
    ptrajoutreservation->show();
}

void empreservation::on_afficher_clicked()
{
ptraff->show();
}

void empreservation::on_annuler_clicked()
{
    ptrsup->show();
}
