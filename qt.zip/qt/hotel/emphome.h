#ifndef EMPHOME_H
#define EMPHOME_H

#include <QDialog>

#include "empclient.h"
#include "empreservation.h"
#include "empdisponibilite.h"

namespace Ui {
class emphome;
}

class emphome : public QDialog
{
    Q_OBJECT

public:
    explicit emphome(QWidget *parent = nullptr);
    ~emphome();

private slots:
    void on_logout_clicked();

    void on_client_clicked();

    void on_reservation_clicked();

    void on_disponibilite_clicked();

private:
    Ui::emphome *ui;

    empclient *ptrempclient;
    empreservation *ptrempreservation;
    empdisponibilite *ptrempdisponibilite;
};

#endif // EMPHOME_H
