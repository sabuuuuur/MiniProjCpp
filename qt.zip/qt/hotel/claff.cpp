#include "claff.h"
#include "ui_claff.h"

claff::claff(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::claff)
{
    ui->setupUi(this);
}

claff::~claff()
{
    delete ui;
}

void claff::on_affiche_clicked()
{
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db");

    if (!QFile::exists("C:/Users/idris/OneDrive/Bureau/qt/qtdb/hotel.db")) {
        qDebug() << "Database file does not exist";
        return;
    }

    if (!database.open()) {
        qDebug() << "Erreur : impossible d'ouvrir la base de données";
        return;
    }



    QString que6,que7,res3,qu;
    QSqlQuery req,query6,query7;


    /*que6="SELECT emaili_cli FROM user";
    query6.prepare(que6);
    //query6.bindValue(":res2",res2);
    query6.exec();
    query6.next();

    res3=query6.value(0).toString();

    qDebug()<<"Halo"<<res3;

    int res2;

    que7="SELECT id_clt FROM client WHERE email=:res3 ";
    query7.prepare(que7);
    query7.bindValue(":res3",res3);
    query7.exec();
    query7.next();

    res2=query7.value(0).toInt();

    qDebug()<<"Halo"<<res2;*/



    int ligne (0);
    qu="select count(*) from client ";
    req.prepare(qu);
    //req.bindValue(":res2",res2);
    req.exec();

    //req.exec("select count(*) from client WHERE id_clt= :res2");
    while (req.next()) {
        ligne=req.value(0).toInt();
    }


    mod2 = new QStandardItemModel (ligne, 8);
    int row(0);

    //req.exec("select id_res, date_arrivee, date_depart, id_clt, id_chamb,id_fact from reservation");
    qu="select id_clt, nom, prenom, email, tel,date_naissance ,sexe ,password from client ";
    req.prepare(qu);
   // req.bindValue(":res2",res2);
    req.exec();
    while (req.next()) {

        for (int j=0 ;j<8;j++) {

            QStandardItem *item = new QStandardItem(req.value (j).toString()) ;
            mod2->setItem(row,j,item);
        }
        row++;

    }

          //QTableView *Ui_checkout::;

        mod2->setHeaderData (0, Qt::Horizontal, "N°client");
        mod2->setHeaderData (1, Qt::Horizontal, "Nom client");
        mod2->setHeaderData (2, Qt::Horizontal, "Prenom client");
        mod2->setHeaderData (3, Qt::Horizontal, "Email client");
        mod2->setHeaderData (4, Qt::Horizontal, "Tel client");
         mod2->setHeaderData (5, Qt::Horizontal, "Date naissance client");
         mod2->setHeaderData (6, Qt::Horizontal, "Sexe client");
         mod2->setHeaderData (7, Qt::Horizontal, "Password client");
        ui->tableView->setModel(mod2);



}
