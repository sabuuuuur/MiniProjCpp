#ifndef EMPCLIENT_H
#define EMPCLIENT_H

#include <QDialog>

#include "ajoutclient.h"
#include "claff.h"
#include "clsup.h"
#include "cludt.h"

namespace Ui {
class empclient;
}

class empclient : public QDialog
{
    Q_OBJECT

public:
    explicit empclient(QWidget *parent = nullptr);
    ~empclient();

private slots:
    void on_ajouter_clicked();

    void on_afficher_clicked();

    void on_modifier_clicked();

    void on_Supprimer_clicked();

private:
    Ui::empclient *ui;

    ajoutclient *ptrajoutclient;
    claff *ptrclaff;
    clsup *ptrclsup;
    cludt *ptrcludt;
};

#endif // EMPCLIENT_H
