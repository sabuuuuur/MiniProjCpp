#ifndef RESAFF_H
#define RESAFF_H

#include <QDialog>
#include "database.h"
#include<QStandardItemModel>

namespace Ui {
class resaff;
}

class resaff : public QDialog
{
    Q_OBJECT

public:
    explicit resaff(QWidget *parent = nullptr);
    ~resaff();

private slots:
    void on_affiche_clicked();

private:
    Ui::resaff *ui;
    QStandardItemModel *mod2;
};

#endif // RESAFF_H
