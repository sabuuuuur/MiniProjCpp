#ifndef DISPONIBILITE_H
#define DISPONIBILITE_H

#include <QDialog>

#include "database.h"

namespace Ui {
class disponibilite;
}

class disponibilite : public QDialog
{
    Q_OBJECT

public:
    explicit disponibilite(QWidget *parent = nullptr);
    ~disponibilite();

private slots:
    void on_affiche_clicked();

private:
    Ui::disponibilite *ui;

    QStandardItemModel *mod;
};

#endif // DISPONIBILITE_H
