#ifndef RESERVATION_H
#define RESERVATION_H

#include <QDialog>

#include "database.h"

namespace Ui {
class reservation;
}

class reservation : public QDialog
{
    Q_OBJECT

public:
    explicit reservation(QWidget *parent = nullptr);
    ~reservation();

private slots:
    void on_load_clicked();
//    void affichagetableview();

    void on_confirme_clicked();

private:
    Ui::reservation *ui;

    QStandardItemModel *mod;
};

#endif // RESERVATION_H
