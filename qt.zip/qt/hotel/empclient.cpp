#include "empclient.h"
#include "ui_empclient.h"

empclient::empclient(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::empclient)
{
    ui->setupUi(this);

    ptrajoutclient=new ajoutclient;
    ptrclaff=new claff;
    ptrclsup=new clsup;
    ptrcludt=new cludt;
}

empclient::~empclient()
{
    delete ui;

    delete ptrajoutclient;
    delete ptrclaff;
    delete ptrclsup;
    delete ptrcludt;
}

void empclient::on_ajouter_clicked()
{
    ptrajoutclient->show();
}

void empclient::on_afficher_clicked()
{
    ptrclaff->show();
}

void empclient::on_modifier_clicked()
{
    ptrcludt->show();
}

void empclient::on_Supprimer_clicked()
{
    ptrclsup->show();
}
